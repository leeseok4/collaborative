import os
from gym import utils
#from gym.envs.mujoco import mujoco_env
from gym.envs.robotics import fetch_env
from DSenv.gripper.DS_gripper_env import DSGripperEnv
from DSenv.gripper.RG6 import RG6Env
import numpy as np
import DSenv.ds_util as ds_util


# Ensure we get the path separator correct on windows
MODEL_XML_PATH = os.path.join(os.path.abspath(os.path.dirname(__file__)), "RG6sj.xml")

class RG6sjEnv(RG6Env, utils.EzPickle):
    def __init__(self, reward_type='spars'):
        initial_qpos = {
            'joint1': np.deg2rad(np.random.randint(low=0, high=90)),
            'joint2': np.deg2rad(np.random.randint(low=0, high=45)),
            'joint3': np.deg2rad(np.random.randint(low=0, high=45)),
            'joint4': 0,
            'joint5': np.deg2rad(np.random.randint(low=0, high=90)),
            'joint6': 0,
            'base_link_joint': 0,
            'finger_joint': np.deg2rad(0),
            'left_inner_finger_joint': 0,
            # 'left_inner_knuckle_joint': 0,
            'right_outer_knuckle_joint': 0,
            'right_inner_finger_joint': 0,
            # 'right_inner_knuckle_joint': 0,
        }

        self.joint_names = ['joint1', 'joint2', 'joint3', 'joint5', 'finger_joint']
        self.tolerance = 1
        self.jog_limit = [[0, 0, 0, 0, -25], [90, 45, 45, 90, 0]]
        self.jog_delta_limit = 10
        self.max_temp = 1000
        self.is_pos_used_in_obs = True
        self.is_printing_temp = False
        self.n_actions = 5

        DSGripperEnv.__init__(
            self, MODEL_XML_PATH, has_object=False, block_gripper=False, n_substeps=20,
            gripper_extra_height=0.2, target_in_the_air=True, target_offset=0.0,
            obj_range=0.15, target_range=0.15, distance_threshold=0.1,
            initial_qpos=initial_qpos, reward_type=reward_type)
        utils.EzPickle.__init__(self)

    def compute_reward(self, achieved_goal, goal, info):
        # Compute distance between goal and the achieved goal.

        d = ds_util.goal_distance(achieved_goal[4:], goal[4:])

        if self.reward_type == 'sparse':
            return -(d > self.distance_threshold).astype(np.float32)
        else:
            return -d

    def _set_action(self, action):
        assert action.shape == (5,)
        action = action.copy()  

        joint = action[:4]
        gripper = action[4]

        if gripper > 0:
            is_joint_action = True

        else:
            is_joint_action = False

        appling_action = [0 for i in range(5)]

        if is_joint_action:
            # Calculate joint action value  
            joint = ds_util.jog_unnormalize(joint, lows=[-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit], 
                                        highs=[self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit])

            # keep previous gripper action value  
            gripper = self.sim.data.get_joint_qpos(self.joint_names[4])

            if gripper > -0.1:
                gripper = [1]
            else:
                gripper = [-1]

        else:
            # Calculate gripper action value  
            gripper = (gripper + 0.5) * 2
            #gripper = ds_util.jog_unnormalize([gripper], lows=[-self.jog_delta_limit], highs=[self.jog_delta_limit])
            if gripper > 0:
                gripper = [1]

            else:
                gripper = [-1]

            joint = np.array([0 for i in range(4)])

        # Get current joint in form of degree from radian.
        cur_joints = []

        for i in range(len(action) - 1):
            cur_joints.append(self.sim.data.get_joint_qpos(self.joint_names[i]))

        cur_joints = np.array(cur_joints)
        cur_joints = np.rad2deg(cur_joints)

        # Sum and clip action to make target joints in form of radian.
        appling_action = joint
        target_joints = cur_joints + appling_action
            
        for i in range(len(action) - 1):
            target_joints[i] = np.clip(target_joints[i], self.jog_limit[0][i], self.jog_limit[1][i])

        target_joints = np.deg2rad(target_joints)

        # Apply joint and gripper action    
        temp = 0

        action_done = False

        while not action_done:
            delta_joints = []
            ctrls = []

            for i in range(len(action) - 1):
                delta_joint = target_joints[i] - self.sim.data.get_joint_qpos(self.joint_names[i])
                delta_joint = np.rad2deg(delta_joint)
                delta_joints.append(delta_joint)

                if delta_joint > 0:
                    delta_joint = 1

                else:
                    delta_joint = -1

                ctrls.append(delta_joint)

            ctrls = np.concatenate((ctrls, gripper), axis=-1)
            ctrls = np.array(ctrls)

            delta_joints = np.array(delta_joints)

            self.sim.data.ctrl[4] = ctrls[4]

            if max(abs(delta_joints)) < self.tolerance:
                action_done = True
                for i in range(len(action) - 1):
                    self.sim.data.ctrl[i] = 0
                self.sim.step()
                break

            for i in range(len(action) - 1):
                self.sim.data.ctrl[i] = ctrls[i]

            self.sim.step()

            temp += 1
            if temp > self.max_temp:
                break
        if self.is_printing_temp:
            print(temp)

    def _get_obs(self):
        dt = self.sim.nsubsteps * self.sim.model.opt.timestep

        # obs : normalized joint and gripper
        jog1 = self.sim.data.get_joint_qpos('joint1')
        jog2 = self.sim.data.get_joint_qpos('joint2')
        jog3 = self.sim.data.get_joint_qpos('joint3')
        jog5 = self.sim.data.get_joint_qpos('joint5')
        gripper = self.sim.data.get_joint_qpos('finger_joint')

        cur_jog = np.array((jog1, jog2, jog3, jog5, gripper))
        cur_jog = np.rad2deg(cur_jog)
        cur_jog = np.array(ds_util.jog_normalize(cur_jog, lows=self.jog_limit[0], highs=self.jog_limit[1]))        
        
        body_id2 = self.sim.model.body_name2id('right_inner_finger')
        lookat2 = self.sim.data.body_xpos[body_id2]

        body_id3 = self.sim.model.body_name2id('left_inner_finger')
        lookat3 = self.sim.data.body_xpos[body_id3]

        lookat0 = (lookat2 + lookat3) / 2

        body_id4 = self.sim.model.body_name2id('base_link')
        lookat4 = self.sim.data.body_xpos[body_id4]

        delta_lookat = lookat0 - lookat4
        lookat5 = delta_lookat * 1.29 + lookat4

        # achieved_goal : coordinates of object to grip
        body_id = self.sim.model.body_name2id('object0')
        pos = self.sim.data.body_xpos[body_id]

        obj_jog = np.array((0, 0.785, 0.785, 1.57, 0))
        obj_jog = np.rad2deg(obj_jog)
        obj_jog = np.array(ds_util.jog_normalize(obj_jog, lows=self.jog_limit[0], highs=self.jog_limit[1]))      
        
        achieved_goal = np.concatenate((cur_jog[:4], pos), axis=-1)
        cur_jog = np.concatenate((cur_jog, obj_jog[:4]), axis=-1)

        obs = np.concatenate((cur_jog, lookat5), axis=-1)

        return {
            'observation': obs.copy(),
            'achieved_goal': achieved_goal.copy(),
            'desired_goal': self.goal.copy(),
        }

    def _render_callback(self):
        # Visualize target.
        # sites_offset = (self.sim.data.site_xpos - self.sim.model.site_pos).copy()
        # site_id = self.sim.model.site_name2id('target0')
        
        # self.sim.model.site_pos[site_id] = self.goal[4:] - sites_offset[0]

        # self.sim.forward()
        jog1 = self.sim.data.get_joint_qpos('joint1')
        jog2 = self.sim.data.get_joint_qpos('joint2')
        jog3 = self.sim.data.get_joint_qpos('joint3')
        jog5 = self.sim.data.get_joint_qpos('joint5')


        self.sim.data.set_joint_qpos('joint1', np.deg2rad(self.goal[0]))
        self.sim.data.set_joint_qpos('joint2', np.deg2rad(self.goal[1]))
        self.sim.data.set_joint_qpos('joint3', np.deg2rad(self.goal[2]))
        self.sim.data.set_joint_qpos('joint5', np.deg2rad(self.goal[3]))
        self.sim.step()

        body_id2 = self.sim.model.body_name2id('right_inner_finger')
        lookat2 = self.sim.data.body_xpos[body_id2]

        body_id3 = self.sim.model.body_name2id('left_inner_finger')
        lookat3 = self.sim.data.body_xpos[body_id3]

        lookat0 = (lookat2 + lookat3) / 2

        self.sim.data.set_joint_qpos('joint1', jog1)
        self.sim.data.set_joint_qpos('joint2', jog2)
        self.sim.data.set_joint_qpos('joint3', jog3)
        self.sim.data.set_joint_qpos('joint5', jog5)
        self.sim.step()
            
        sites_offset = (self.sim.data.site_xpos - self.sim.model.site_pos).copy()
        site_id = self.sim.model.site_name2id('target0')
        self.sim.model.site_pos[site_id] = lookat0 - sites_offset[0]
        self.sim.forward()

    def _reset_sim(self):
        self.sim.set_state(self.initial_state)

        # Randomize start position of object.
        if self.has_object:
            object_xpos = self.initial_gripper_xpos[:2]
            while np.linalg.norm(object_xpos - self.initial_gripper_xpos[:2]) < 0.1:
                object_xpos = self.initial_gripper_xpos[:2] + self.np_random.uniform(-self.obj_range, self.obj_range, size=2)
            object_qpos = self.sim.data.get_joint_qpos('object0:joint')
            assert object_qpos.shape == (7,)
            object_qpos[:2] = object_xpos
            self.sim.data.set_joint_qpos('object0:joint', object_qpos)

        self.sim.forward()
        return True

    def _sample_goal(self):
        if self.has_object:
            goal = self.initial_gripper_xpos[:3] + self.np_random.uniform(-self.target_range, self.target_range, size=3)
            goal += self.target_offset
            goal[2] = self.height_offset
            if self.target_in_the_air and self.np_random.uniform() < 0.5:
                goal[2] += self.np_random.uniform(0, 0.45)
        else:
            j1 = np.random.randint(low=self.jog_limit[0][0], high=self.jog_limit[1][0])
            j2 = np.random.randint(low=self.jog_limit[0][1], high=self.jog_limit[1][1])
            j3 = np.random.randint(low=self.jog_limit[0][2], high=self.jog_limit[1][2])
            j5 = np.random.randint(low=self.jog_limit[0][3], high=self.jog_limit[1][3])
            gripper = 0
            body_id = self.sim.model.body_name2id('object0')
            finger_joint = self.sim.data.body_xpos[body_id]
            #gripper = np.random.randint(low=self.jog_limit[0][3], high=self.jog_limit[1][3])
            # #goal = np.array([j1,j2,j3,j5,gripper])
            # goal = np.array([j1,j2,j3,j5,finger_joint])
            cur_jog = np.array((j1, j2, j3, j5, gripper))
            goal = np.concatenate((cur_jog[:4],finger_joint), axis=-1)
            self.normalized_goal = np.array(ds_util.jog_normalize(goal, lows=self.jog_limit[0], highs=self.jog_limit[1]))
       
        return goal.copy()

    def _is_success(self, achieved_goal, desired_goal):

        #achieved_goal = achieved_goal[:2]
        #desired_goal = desired_goal[:2]

        d = ds_util.goal_distance(achieved_goal, desired_goal)

        #if self.has_object:

        return (d < self.distance_threshold).astype(np.float32)


    def _env_setup(self, initial_qpos):
        for name, value in initial_qpos.items():
            self.sim.data.set_joint_qpos(name, value)

        #gym.envs.robotics.utils.reset_mocap_welds(self.sim)
        self.sim.forward()