import os
from gym import utils
#from gym.envs.mujoco import mujoco_env
from gym.envs.robotics import fetch_env
from DSenv.gripper.DS_gripper_env import DSGripperEnv
import numpy as np
import DSenv.ds_util as ds_util


# Ensure we get the path separator correct on windows
MODEL_XML_PATH = os.path.join(os.path.abspath(os.path.dirname(__file__)), "RG6S.xml")

class RG6SEnv(DSGripperEnv, utils.EzPickle):
    def __init__(self, reward_type='sparse'):
        initial_qpos = {
            'joint1': 0,
            # 'joint2': np.deg2rad(25),
            'joint2': np.deg2rad(0),
            # 'joint3': np.deg2rad(25),
            'joint3': np.deg2rad(0),
            'joint4': 0,
            # 'joint5': np.deg2rad(60),
            'joint5': np.deg2rad(0),
            'joint6': 0,
            'base_link_joint': 0,
            'finger_joint': 0,
            'left_inner_finger_joint': 0,
            #'left_inner_knuckle_joint': 0,
            'right_outer_knuckle_joint': 0,
            'right_inner_finger_joint': 0,
            #'right_inner_knuckle_joint': 0,
        }
        # self.jog_limit = [[-180, 0, 0, 0], [180, 45, 45, 150]]
        self.joint_names = ['joint1', 'joint2', 'joint3', 'joint5', 'finger_joint']
        
        # full space
        self.jog_limit = [[-180, 0, 0, 0, 0], [180, 45, 45, 150,0]]
        
        # narrow space
        # self.jog_limit = [[-20, 25, 25, 60, 0], [20, 45, 45, 90,0]]

        self.jog_delta_limit = 30
        self.n_actions = 5
        
        DSGripperEnv.__init__(
            self, MODEL_XML_PATH, has_object=False, block_gripper=True, n_substeps=1,
            gripper_extra_height=0.2, target_in_the_air=True, target_offset=0.0,
            obj_range=0.15, target_range=0.15, distance_threshold=2,
            initial_qpos=initial_qpos, reward_type=reward_type)
        utils.EzPickle.__init__(self)

        self.distance_threshold_2 = 1
        self.jog_delta_limit_2 = 1
        # self.jog_limit = [[-20, 25, 25, 60], [20, 45, 45, 90]]
        # self.jog_limit = [[-5, 40, 40, 80], [5, 45, 45, 90]]
        #self.jog_limit = [[-20, 20, 20, 60], [20, 45, 45, 90]]
        #self.full_jog_limit = [[self.jog_limit[0][0], self.jog_limit[0][1], self.jog_limit[0][2], 0, self.jog_limit[0][3], 0], 
                            #[self.jog_limit[1][0], self.jog_limit[1][1], self.jog_limit[1][2], 0, self.jog_limit[1][3], 0]]

        


    # GoalEnv methods
    # ----------------------------

    def compute_reward(self, achieved_goal, goal, i_level):
        # Compute distance between goal and the achieved goal.
        #d = goal_distance(achieved_goal, self.normalized_goal)

        if i_level == 0:
            unnormalized_ag = np.array(ds_util.jog_unnormalize(achieved_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
            unnormalized_g = np.array(ds_util.jog_unnormalize(goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
            # print("leve1 RG6 state: {} subgoal:{}".format(unnormalized_ag,unnormalized_g))
        else:
            unnormalized_ag = np.array(ds_util.jog_unnormalize(achieved_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
            unnormalized_g = np.array(ds_util.jog_unnormalize(self.normalized_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
            # print("level2 RG6 state: {} goal:{}".format(unnormalized_ag,unnormalized_g))

        d = ds_util.goal_distance(unnormalized_ag, unnormalized_g)
        

        # print(self.normalized_goal,"1")
        if self.reward_type == 'sparse':
            d=-(d > self.distance_threshold).astype(np.float32)
            # if d==0:
                # print("state:{},goal:{},sub:{}".format(unnormalized_ag,unnormalized_g,i_level))
            
        else:
            d=-d

        return d


    

    # RobotEnv methods
    # ----------------------------

    def _step_callback(self):
        if self.block_gripper:
            self.sim.forward()

    def _set_action(self, action):
        assert action.shape == (5,)
        action = action.copy()  # ensure that we don't change the action outside of this scope
        #pos_ctrl, gripper_ctrl = action[:3], action[3]

        #pos_ctrl *= 0.05  # limit maximum change in position
        #rot_ctrl = [1., 0., 1., 0.]  # fixed rotation of the end effector, expressed as a quaternion
        #gripper_ctrl = np.array([gripper_ctrl, gripper_ctrl])
        #assert gripper_ctrl.shape == (2,)
        #if self.block_gripper:
        #    gripper_ctrl = np.zeros_like(gripper_ctrl)
        #action = np.concatenate([pos_ctrl, rot_ctrl, gripper_ctrl])

        
        #action = np.array([action[0],action[1],action[2],0,action[3],0])
        # Apply action to simulation.
        jog1 = self.sim.data.get_joint_qpos('joint1')
        jog2 = self.sim.data.get_joint_qpos('joint2')
        jog3 = self.sim.data.get_joint_qpos('joint3')
        jog5 = self.sim.data.get_joint_qpos('joint5')
        gripper = 0

        #gripper = self.sim.data.get_joint_qpos('finger_joint')

        #cur_jog = np.array((jog1, jog2, jog3, jog5, gripper))
        cur_jog = np.array((jog1, jog2, jog3, jog5, gripper))
        cur_jog = np.rad2deg(cur_jog)
        d_1 = ds_util.goal_distance(cur_jog ,self.normalized_goal)
        
        # if d_1 > self.distance_threshold_2:
        #     action = ds_util.jog_unnormalize(action, lows=[-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit,0], 
        #                             highs=[self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit,0])
        #     # print("RG6 action:{}".format(action))
        # else:
        #     action = ds_util.jog_unnormalize(action, lows=[-self.jog_delta_limit_2,-self.jog_delta_limit_2,-self.jog_delta_limit_2,-self.jog_delta_limit_2,0], 
        #                             highs=[self.jog_delta_limit_2,self.jog_delta_limit_2,self.jog_delta_limit_2,self.jog_delta_limit_2,0])
            
        action = ds_util.jog_unnormalize(action, lows=[-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit,1], 
                                    highs=[self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit,1])
        #action.append(0)
        #action = jog_unnormalize(action, lows=self.jog_limit[0], highs=self.jog_limit[1])

        """
        action = [action[0], action[1], action[2], 0, action[3], 0]
        action = np.array(action)

        state = self.sim.get_state()
        cur_jog = state.qpos
        cur_jog = np.rad2deg(cur_jog)
        
        delta_jog = np.subtract(action, cur_jog)
        clipped_jog = np.clip(delta_jog, -self.jog_delta_limit, self.jog_delta_limit)
        clipped_sum_jog = np.add(cur_jog, clipped_jog)

        

        cur_jog += action
        clipped_jog = [0,0,0,0]
        clipped_jog[0] = np.clip(cur_jog[0], self.jog_limit[0][0], self.jog_limit[1][0])
        clipped_jog[1] = np.clip(cur_jog[1], self.jog_limit[0][1], self.jog_limit[1][1])
        clipped_jog[2] = np.clip(cur_jog[2], self.jog_limit[0][2], self.jog_limit[1][2])
        clipped_jog[3] = np.clip(cur_jog[4], self.jog_limit[0][3], self.jog_limit[1][3])
        """

        action = np.array(action)

        # state = self.sim.get_state()
        # cur_jog = state.qpos
        # cur_jog = np.rad2deg(cur_jog)
        # cur_jog = np.array([cur_jog[0], cur_jog[1], cur_jog[2], cur_jog[4]])
      

        cur_jog += action
        cur_jog[0] = np.clip(cur_jog[0], self.jog_limit[0][0], self.jog_limit[1][0])
        cur_jog[1] = np.clip(cur_jog[1], self.jog_limit[0][1], self.jog_limit[1][1])
        cur_jog[2] = np.clip(cur_jog[2], self.jog_limit[0][2], self.jog_limit[1][2])
        cur_jog[3] = np.clip(cur_jog[3], self.jog_limit[0][3], self.jog_limit[1][3])

        # print("jog:{}".format(cur_jog))

        #clipped_sum_jog = np.deg2rad(clipped_sum_jog)
        clipped_sum_jog = np.deg2rad(cur_jog)
        
        #print(self.sim.data.get_joint_xpos('joint6'))

        self.sim.data.set_joint_qpos('joint1', clipped_sum_jog[0])
        self.sim.data.set_joint_qpos('joint2', clipped_sum_jog[1])
        self.sim.data.set_joint_qpos('joint3', clipped_sum_jog[2])
        self.sim.data.set_joint_qpos('joint5', clipped_sum_jog[3])

        #self.sim.data.set_joint_qpos('finger_joint', 0)
        #self.sim.data.set_joint_qpos('joint5', clipped_sum_jog[4])

        #print(self.sim.data.get_joint_xpos('joint6'))
        #print(action, np.rad2deg(self.sim.get_state().qpos))

        #utils.ctrl_set_action(self.sim, action)
        #utils.mocap_set_action(self.sim, action)

    def _get_obs(self):
        # positions
        #cur_pos = self.sim.data.get_joint_xpos('joint6')
        dt = self.sim.nsubsteps * self.sim.model.opt.timestep

        jog1 = self.sim.data.get_joint_qpos('joint1')
        jog2 = self.sim.data.get_joint_qpos('joint2')
        jog3 = self.sim.data.get_joint_qpos('joint3')
        jog5 = self.sim.data.get_joint_qpos('joint5')
        gripper = self.sim.data.get_joint_qpos('finger_joint')

        #gripper = self.sim.data.get_joint_qpos('finger_joint')
        #cur_jog = np.array((jog1, jog2, jog3, jog5, gripper))
        cur_jog = np.array((jog1, jog2, jog3, jog5, gripper))
        cur_jog = np.rad2deg(cur_jog)

        #print(cur_jog, self.goal)

        cur_jog1 = np.array(ds_util.jog_normalize(cur_jog, lows=self.jog_limit[0], highs=self.jog_limit[1]))        


        achieved_goal = cur_jog1.copy()

        obs1 = np.concatenate([cur_jog1])
        obs = np.concatenate([cur_jog])

        return {
            'observation': obs1.copy(),
            'observation_original': obs.copy(),
            'achieved_goal': achieved_goal.copy(),
            'desired_goal': self.normalized_goal,
            'desired_goal_original' : self.goal,
        }

        

    def _viewer_setup(self):
        body_id = self.sim.model.body_name2id('link6')
        lookat = self.sim.data.body_xpos[body_id]
        for idx, value in enumerate(lookat):
            self.viewer.cam.lookat[idx] = value
        self.viewer.cam.distance = 2.5
        self.viewer.cam.azimuth = 132.
        self.viewer.cam.elevation = -14.

    def _render_callback(self):
        # Visualize target.

        jog1 = self.sim.data.get_joint_qpos('joint1')
        jog2 = self.sim.data.get_joint_qpos('joint2')
        jog3 = self.sim.data.get_joint_qpos('joint3')
        jog5 = self.sim.data.get_joint_qpos('joint5')


        self.sim.data.set_joint_qpos('joint1', np.deg2rad(self.goal[0]))
        self.sim.data.set_joint_qpos('joint2', np.deg2rad(self.goal[1]))
        self.sim.data.set_joint_qpos('joint3', np.deg2rad(self.goal[2]))
        self.sim.data.set_joint_qpos('joint5', np.deg2rad(self.goal[3]))
        self.sim.step()

        body_id2 = self.sim.model.body_name2id('right_inner_finger')
        lookat2 = self.sim.data.body_xpos[body_id2]

        body_id3 = self.sim.model.body_name2id('left_inner_finger')
        lookat3 = self.sim.data.body_xpos[body_id3]

        lookat0 = (lookat2 + lookat3) / 2

        self.sim.data.set_joint_qpos('joint1', jog1)
        self.sim.data.set_joint_qpos('joint2', jog2)
        self.sim.data.set_joint_qpos('joint3', jog3)
        self.sim.data.set_joint_qpos('joint5', jog5)
        self.sim.step()
            
        sites_offset = (self.sim.data.site_xpos - self.sim.model.site_pos).copy()
        site_id = self.sim.model.site_name2id('target0')
        self.sim.model.site_pos[site_id] = lookat0 - sites_offset[0]
        self.sim.forward()


    def _reset_sim(self):
        self.sim.set_state(self.initial_state)

        # Randomize start position of object.
        if self.has_object:
            object_xpos = self.initial_gripper_xpos[:2]
            while np.linalg.norm(object_xpos - self.initial_gripper_xpos[:2]) < 0.1:
                object_xpos = self.initial_gripper_xpos[:2] + self.np_random.uniform(-self.obj_range, self.obj_range, size=2)
            object_qpos = self.sim.data.get_joint_qpos('object0:joint')
            assert object_qpos.shape == (7,)
            object_qpos[:2] = object_xpos
            self.sim.data.set_joint_qpos('object0:joint', object_qpos)

        self.sim.forward()
        return True

    def _sample_goal(self):
        if self.has_object:
            goal = self.initial_gripper_xpos[:3] + self.np_random.uniform(-self.target_range, self.target_range, size=3)
            goal += self.target_offset
            goal[2] = self.height_offset
            if self.target_in_the_air and self.np_random.uniform() < 0.5:
                goal[2] += self.np_random.uniform(0, 0.45)
        else:
            j1 = np.random.randint(low=self.jog_limit[0][0], high=self.jog_limit[1][0])
            j2 = np.random.randint(low=self.jog_limit[0][1], high=self.jog_limit[1][1])
            j3 = np.random.randint(low=self.jog_limit[0][2], high=self.jog_limit[1][2])
            j5 = np.random.randint(low=self.jog_limit[0][3], high=self.jog_limit[1][3])
            # j1 = -90
            # j2 = 20
            # j3 = 30
            # j5 = 130
            gripper = 0
            #gripper = np.random.randint(low=self.jog_limit[0][3], high=self.jog_limit[1][3])
            #goal = np.array([j1,j2,j3,j5,gripper])
            goal = np.array([j1,j2,j3,j5, gripper])
            self.goal = goal
            self.normalized_goal = np.array(ds_util.jog_normalize(goal, lows=self.jog_limit[0], highs=self.jog_limit[1]))

        return goal.copy()

    def _is_success(self, achieved_goal, desired_goal):
        d = ds_util.goal_distance(achieved_goal, desired_goal)
        return (d < self.distance_threshold).astype(np.float32)

    def clear_goal(self, achieved_goal, goal, i_level):
        
        if i_level == 0:
            unnormalized_ag = np.array(ds_util.jog_unnormalize(achieved_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
            unnormalized_g = np.array(ds_util.jog_unnormalize(goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
            # print("leve1 RG6 state: {} subgoal:{}".format(unnormalized_ag,unnormalized_g))
        else:
            unnormalized_ag = np.array(ds_util.jog_unnormalize(achieved_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
            unnormalized_g = np.array(ds_util.jog_unnormalize(self.normalized_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
            # print("level2 RG6 state: {} goal:{}".format(unnormalized_ag,unnormalized_g))

        d = ds_util.goal_distance(unnormalized_ag, unnormalized_g)
        return (d < self.distance_threshold).astype(np.float32)
        

    def _env_setup(self, initial_qpos):
        for name, value in initial_qpos.items():
            self.sim.data.set_joint_qpos(name, value)
        #utils.reset_mocap_welds(self.sim)
        self.sim.forward()

        # Move end effector into position.
        #gripper_target = np.array([-0.498, 0.005, -0.431 + self.gripper_extra_height]) + self.sim.data.get_site_xpos('robot0:grip')
        #gripper_rotation = np.array([1., 0., 1., 0.])
        #self.sim.data.set_mocap_pos('robot0:mocap', gripper_target)
        #self.sim.data.set_mocap_quat('robot0:mocap', gripper_rotation)
        for _ in range(10):
            self.sim.step()

        # Extract information for sampling goals.
        #self.initial_gripper_xpos = self.sim.data.get_site_xpos('robot0:grip').copy()
        #if self.has_object:
        #    self.height_offset = self.sim.data.get_site_xpos('object0')[2]

    def render(self, mode='human', width=500, height=500):
        return super(RG6SEnv, self).render(mode, width, height)