import numpy as np

from gym.envs.robotics import rotations, robot_env, utils
import DSenv.ds_util as ds_util

class DSGripperEnv(robot_env.RobotEnv):
    """Superclass for all Fetch environments.
    """

    def __init__(
        self, model_path, n_substeps, gripper_extra_height, block_gripper,
        has_object, target_in_the_air, target_offset, obj_range, target_range,
        distance_threshold, initial_qpos, reward_type,
    ):
        """Initializes a new Fetch environment.

        Args:
            model_path (string): path to the environments XML file
            n_substeps (int): number of substeps the simulation runs on every call to step
            gripper_extra_height (float): additional height above the table when positioning the gripper
            block_gripper (boolean): whether or not the gripper is blocked (i.e. not movable) or not
            has_object (boolean): whether or not the environment has an object
            target_in_the_air (boolean): whether or not the target should be in the air above the table or on the table surface
            target_offset (float or array with 3 elements): offset of the target
            obj_range (float): range of a uniform distribution for sampling initial object positions
            target_range (float): range of a uniform distribution for sampling a target
            distance_threshold (float): the threshold after which a goal is considered achieved
            initial_qpos (dict): a dictionary of joint names and values that define the initial configuration
            reward_type ('sparse' or 'dense'): the reward type, i.e. sparse or dense
        """
        self.gripper_extra_height = gripper_extra_height
        self.block_gripper = block_gripper
        self.has_object = has_object
        self.target_in_the_air = target_in_the_air
        self.target_offset = target_offset
        self.obj_range = obj_range
        self.target_range = target_range
        self.distance_threshold = distance_threshold
        self.reward_type = reward_type

        super(DSGripperEnv, self).__init__(
            model_path=model_path, n_substeps=n_substeps, n_actions=self.n_actions,
            initial_qpos=initial_qpos)

    # GoalEnv methods
    # ----------------------------

    def compute_reward(self, achieved_goal, goal, info):
        # Compute distance between goal and the achieved goal.
        #d = goal_distance(achieved_goal, self.normalized_goal)

        unnormalized_ag = np.array(ds_util.jog_unnormalize(achieved_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
        unnormalized_g = np.array(ds_util.jog_unnormalize(self.normalized_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 

        d = ds_util.goal_distance(unnormalized_ag, unnormalized_g)
        if self.reward_type == 'sparse':
            return -(d > self.distance_threshold).astype(np.float32)
        else:
            return -d

    # RobotEnv methods
    # ----------------------------

    def _step_callback(self):
        if self.block_gripper:
            self.sim.forward()

    def _set_action(self, action):
        assert action.shape == (5,)
        action = action.copy()  

        action = ds_util.jog_unnormalize(action, lows=[-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit], 
                                        highs=[self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit])
        #action = jog_unnormalize(action, lows=self.jog_limit[0], highs=self.jog_limit[1])

        jog = action[4]
        #action = [0,0,0,0,0]
        action = [0, 45,45,90,-15]
        #action = np.array(action)
        action[4] = jog

        # Get current joint from radian to degree
        jog1 = self.sim.data.get_joint_qpos('joint1')
        jog2 = self.sim.data.get_joint_qpos('joint2')
        jog3 = self.sim.data.get_joint_qpos('joint3')
        jog5 = self.sim.data.get_joint_qpos('joint5')
        gripper_jog = self.sim.data.get_joint_qpos('finger_joint')

        cur_jog = np.array([jog1, jog2, jog3, jog5, gripper_jog])
        cur_jog = np.rad2deg(cur_jog)

        # Sum and clip action
        cur_jog += action
        cur_jog[0] = np.clip(cur_jog[0], self.jog_limit[0][0], self.jog_limit[1][0])
        cur_jog[1] = np.clip(cur_jog[1], self.jog_limit[0][1], self.jog_limit[1][1])
        cur_jog[2] = np.clip(cur_jog[2], self.jog_limit[0][2], self.jog_limit[1][2])
        cur_jog[3] = np.clip(cur_jog[3], self.jog_limit[0][3], self.jog_limit[1][3])
        cur_jog[4] = np.clip(cur_jog[4], self.jog_limit[0][4], self.jog_limit[1][4])

        #clipped_sum_jog = np.deg2rad(clipped_sum_jog)
        clipped_sum_jog = np.deg2rad(cur_jog)
        
        #print(self.sim.data.get_joint_xpos('joint6'))

        self.sim.data.set_joint_qpos('joint1', clipped_sum_jog[0])
        self.sim.data.set_joint_qpos('joint2', clipped_sum_jog[1])
        self.sim.data.set_joint_qpos('joint3', clipped_sum_jog[2])
        self.sim.data.set_joint_qpos('joint5', clipped_sum_jog[3])
        #self.sim.data.set_joint_qpos('joint5', clipped_sum_jog[4])


        #clipped_sum_jog[4] = np.deg2rad(-15)
        self.sim.data.set_joint_qpos('finger_joint', clipped_sum_jog[4])
        self.sim.data.set_joint_qpos('left_inner_finger_joint', -clipped_sum_jog[4])
        self.sim.data.set_joint_qpos('left_inner_knuckle_joint', clipped_sum_jog[4])
        self.sim.data.set_joint_qpos('right_outer_knuckle_joint', clipped_sum_jog[4])
        self.sim.data.set_joint_qpos('right_inner_finger_joint', -clipped_sum_jog[4])
        self.sim.data.set_joint_qpos('right_inner_knuckle_joint', clipped_sum_jog[4])
        #print(self.sim.data.get_joint_xpos('joint6'))
        #print(action, np.rad2deg(self.sim.get_state().qpos))

        #utils.ctrl_set_action(self.sim, action)
        #utils.mocap_set_action(self.sim, action)


        #for i in range(action.shape[0]):
        #    self.sim.data.ctrl[i] = action[i]
            

        #pos_delta = np.array([0,0,0])

        #utils.reset_mocap2body_xpos(self.sim)
        #self.sim.data.mocap_pos[:] = self.sim.data.mocap_pos + pos_delta

    def _get_obs(self):
        # positions
        #cur_pos = self.sim.data.get_joint_xpos('base_link_joint')
        dt = self.sim.nsubsteps * self.sim.model.opt.timestep

        jog1 = self.sim.data.get_joint_qpos('joint1')
        jog2 = self.sim.data.get_joint_qpos('joint2')
        jog3 = self.sim.data.get_joint_qpos('joint3')
        jog5 = self.sim.data.get_joint_qpos('joint5')

        gripper = self.sim.data.get_joint_qpos('finger_joint')

        cur_jog = np.array((jog1, jog2, jog3, jog5, gripper))
        cur_jog = np.rad2deg(cur_jog)

        #gripper_xpos = self.sim.data.get_site_xpos('robot0:grip').copy()
        #print(cur_jog, self.goal)

        cur_jog = np.array(ds_util.jog_normalize(cur_jog, lows=self.jog_limit[0], highs=self.jog_limit[1]))        



        body_id = self.sim.model.body_name2id('base_link')
        lookat = self.sim.data.body_xpos[body_id]
       
        body_id2 = self.sim.model.body_name2id('right_inner_finger')
        lookat2 = self.sim.data.body_xpos[body_id2]

        body_id3 = self.sim.model.body_name2id('left_inner_finger')
        lookat3 = self.sim.data.body_xpos[body_id3]

        lookat0 = (lookat2 + lookat3) / 2

        achieved_goal = np.concatenate((lookat, cur_jog), axis=-1)

        obs = np.concatenate((lookat, cur_jog), axis=-1)

        return {
            'observation': obs.copy(),
            'achieved_goal': achieved_goal.copy(),
            'desired_goal': self.normalized_goal,
            #'desired_goal': self.goal.copy(),
        }

    def _viewer_setup(self):
        #body_id = self.sim.model.body_name2id('robot0:gripper_link')
        body_id = self.sim.model.body_name2id('base_link')
        lookat = self.sim.data.body_xpos[body_id]
        for idx, value in enumerate(lookat):
            self.viewer.cam.lookat[idx] = value
        self.viewer.cam.distance = 2.5
        self.viewer.cam.azimuth = 132.
        self.viewer.cam.elevation = -14.

    def _render_callback(self):
        # Visualize target.
        #sites_offset = (self.sim.data.site_xpos - self.sim.model.site_pos).copy()
        #site_id = self.env.sim.model.body_pos[self.env.sim.model.body_name2id("target0")]
        site_id = self.sim.model.site_name2id('target0')
        #self.sim.model.site_pos[site_id] = self.goal - sites_offset[0]
        #self.sim.model.site_pos[site_id] = self.goal 
        self.sim.model.site_pos[site_id] = np.array([0,0,0]) 
        self.sim.forward()

    def _reset_sim(self):
        self.sim.set_state(self.initial_state)

        # Randomize start position of object.
        if self.has_object:
            x = 0
            y = 0.65
            z = 0.32
            object_xpos = np.array([x,y,z])
            object_qpos = self.sim.data.get_joint_qpos('object0:joint')
            assert object_qpos.shape == (7,)
            #object_qpos[:2] = object_xpos
            #self.sim.data.set_joint_qpos('object0:joint', object_qpos)

        self.sim.forward()
        return True

    def _sample_goal(self):
        if self.has_object:
            x = 0
            y = 0.65
            z = 0.32
            j1 = 0
            j2 = 45
            j3 = 45
            j5 = 90
            gripper = 10
            joint = np.array([j1,j2,j3,j5, gripper])
            normalized_joint = np.array(ds_util.jog_normalize(joint, lows=self.jog_limit[0], highs=self.jog_limit[1]))
            goal = np.concatenate((np.array([x,y,z]), normalized_joint), axis=-1)
            self.normalized_goal = goal

        else:
            j1 = np.random.randint(low=self.jog_limit[0][0], high=self.jog_limit[1][0])
            j2 = np.random.randint(low=self.jog_limit[0][1], high=self.jog_limit[1][1])
            j3 = np.random.randint(low=self.jog_limit[0][2], high=self.jog_limit[1][2])
            j5 = np.random.randint(low=self.jog_limit[0][3], high=self.jog_limit[1][3])
            goal = np.array([j1,j2,j3,j5])
            self.normalized_goal = np.array(ds_util.jog_normalize(goal, lows=self.jog_limit[0], highs=self.jog_limit[1]))

        return goal.copy()

    def _is_success(self, achieved_goal, desired_goal):

        achieved_goal = achieved_goal[:2]
        desired_goal = desired_goal[:2]

        d = ds_util.goal_distance(achieved_goal, desired_goal)

        #if self.has_object:

        return (d < self.distance_threshold).astype(np.float32)

    def _env_setup(self, initial_qpos):
        for name, value in initial_qpos.items():
            self.sim.data.set_joint_qpos(name, value)
        utils.reset_mocap_welds(self.sim)
        self.sim.forward()

        # Move end effector into position.
        #gripper_target = np.array([-0.498, 0.005, -0.431 + self.gripper_extra_height]) + self.sim.data.get_site_xpos('robot0:grip')
        #gripper_rotation = np.array([1., 0., 1., 0.])
        #self.sim.data.set_mocap_pos('robot0:mocap', gripper_target)
        #self.sim.data.set_mocap_quat('robot0:mocap', gripper_rotation)
        for _ in range(10):
            self.sim.step()

        # Extract information for sampling goals.
        #self.initial_gripper_xpos = self.sim.data.get_site_xpos('robot0:grip').copy()
        #if self.has_object:
        #    self.height_offset = self.sim.data.get_site_xpos('object0')[2]

    def render(self, mode='human', width=500, height=500):
        return super(DSGripperEnv, self).render(mode, width, height)
