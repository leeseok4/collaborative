import os, sys
import random
import pickle
import numpy as np

class ReplayMemory:
    def __init__(self, capacity, seed):
        random.seed(seed)
        self.capacity = capacity
        self.buffer = []
        self.her_buffer = []
        self.idx = 0
        self.her_idx = 0
        self.future_p = 0.8

    def push(self, state, action, reward, next_state, done):
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.idx] = (state, action, reward, next_state, done)
        self.idx = (self.idx + 1) % self.capacity

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = map(np.stack, zip(*batch))
        return state, action, reward, next_state, done

    def __len__(self):
        return len(self.buffer)

    def save_buffer(self, env_name, suffix="", save_path=None):
        if not os.path.exists('checkpoints/'):
            os.makedirs('checkpoints/')

        if save_path is None:
            save_path = "checkpoints/sac_buffer_{}_{}".format(env_name, suffix)
        print('Saving buffer to {}'.format(save_path))

        with open(save_path, 'wb') as f:
            pickle.dump(self.buffer, f)
            pickle.dump(self.her_buffer, f)

    def load_buffer(self, save_path):
        print('Loading buffer from {}'.format(save_path))

        with open(save_path, "rb") as f:
            self.buffer = pickle.load(f)
            self.idx = len(self.buffer) % self.capacity
            self.her_buffer = pickle.load(f)
            self.her_idx = len(self.her_buffer) % self.capacity

    def her_push(self, state, action, reward, next_state, done):
        if len(self.her_buffer) < self.capacity:
            self.her_buffer.append(None)
        self.her_buffer[self.her_idx] = (state, action, reward, next_state, done)
        self.her_idx = (self.her_idx + 1) % self.capacity

    def her_sample(self, batch_size):
        batch = random.sample(self.buffer, 51)
        her_batch = random.sample(self.her_buffer, 205)
        sum_batch = np.concatenate((batch, her_batch), axis=0)
        state, action, reward, next_state, done = map(np.stack, zip(*sum_batch))
        return state, action, reward, next_state, done