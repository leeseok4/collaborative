import os, sys
base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
sys.path.append(base_dir)
import argparse
import datetime
import gym
import numpy as np
import itertools
import torch
from HAC_grip import HAC
from torch.utils.tensorboard import SummaryWriter
from utils import ReplayBuffer

import DSenv
from gym.envs.robotics.fetch.reach import FetchReachEnv

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

parser = argparse.ArgumentParser(description='PyTorch Soft Actor-Critic Args')
parser.add_argument('--env-name', default="FetchReach-v1",
                    help='Mujoco Gym environment (default: HalfCheetah-v2)')
parser.add_argument('--policy', default="Gaussian",

                    help='Policy Type: Gaussian | Deterministic (default: Gaussian)')
parser.add_argument('--eval', type=bool, default=True,
                    help='Evaluates a policy a policy every 10 episode (default: True)')
parser.add_argument('--gamma', type=float, default=0.99, metavar='G',
                    help='discount factor for reward (default: 0.99)')
parser.add_argument('--tau', type=float, default=0.005, metavar='G',
                    help='target smoothing coefficient(τ) (default: 0.005)')
parser.add_argument('--lr', type=float, default=0.0003, metavar='G',
                    help='learning rate (default: 0.0003)')
parser.add_argument('--alpha', type=float, default=0.2, metavar='G',
                    help='Temperature parameter α determines the relative importance of the entropy\
                            term against the reward (default: 0.2)')
parser.add_argument('--automatic_entropy_tuning', type=bool, default=True, metavar='G',
                    help='Automaically adjust α (default: False)')
parser.add_argument('--seed', type=int, default=123456, metavar='N',
                    help='random seed (default: 123456)')
parser.add_argument('--batch_size', type=int, default=256, metavar='N',
                    help='batch size (default: 256)')
parser.add_argument('--num_steps', type=int, default=10000001, metavar='N',
                    help='maximum number of steps (default: 1000000)')
parser.add_argument('--hidden_size', type=int, default=256, metavar='N',
                    help='hidden size (default: 256)')
parser.add_argument('--updates_per_step', type=int, default=1, metavar='N',
                    help='model updates per simulator step (default: 1)')
parser.add_argument('--start_steps', type=int, default=10000, metavar='N',
                    help='Steps sampling random actions (default: 10000)')
parser.add_argument('--target_update_interval', type=int, default=1, metavar='N',
                    help='Value target update per no. of updates per step (default: 1)')
parser.add_argument('--capacity', type=int, default=1000000, metavar='N',
                    help='size of replay buffer (default: 10000000)')
parser.add_argument('--cuda', action="store_true",
                    help='run on CUDA (default: False)')
args = parser.parse_args()


checkpoint_name = 'f5'

args.cuda = False
render = False
env_name = 'RG6SG-v0'
env = gym.make('RG6SG-v0')
#env = gym.make('RG6-v0')

env.seed(args.seed)
env.action_space.seed(args.seed)

torch.manual_seed(args.seed)
np.random.seed(args.seed)

save_episode = 20                   # keep saving every n episodes
max_episodes = 10000000             # max num of training episodes
random_seed = 0

state_dim = 4
action_dim = 4

"""
    Actions (both primitive and subgoal) are implemented as follows:
    action = ( network output (Tanh) * bounds ) + offset
    clip_high and clip_low bound the exploration noise
"""
# primitive action bounds and offset
# action_bounds = env.action_space.high[0]
action_bounds_np = np.array([1,1,1,1])
action_bounds = torch.FloatTensor(action_bounds_np.reshape(1, -1)).to(device)

# action_offset = np.array([0.0])
# action_offset = torch.FloatTensor(action_offset.reshape(1, -1)).to(device)
# action_clip_low = np.array([-1.0 * action_bounds])
# action_clip_high = np.array([action_bounds])
action_clip_low = np.array([-1, -1, -1, -1])
action_clip_high = np.array([1, 1, 1, 1])


# state bounds and offset
state_bounds_np = np.array([1,1,1,1])
state_bounds = torch.FloatTensor(state_bounds_np.reshape(1, -1)).to(device)
# state_offset =  np.array([-0.3, 0.0])
# state_offset = torch.FloatTensor(state_offset.reshape(1, -1)).to(device)
state_clip_low = np.array([-1, -1, -1, -1])
state_clip_high = np.array([1, 1, 1, 1])

# exploration noise std for primitive action and subgoals
# exploration_action_noise = np.array([0.1])        
exploration_action_noise = 0.1        
exploration_state_noise = np.array([0.02, 0.01]) 

# goal_state = np.array([0.48, 0.04])        # final goal state to be achived
threshold = np.array([0.5, 0.5, 0.5, 0.5, 0])         # threshold value to check if goal state is achieved

# HAC parameters:
k_level = 2                 # num of levels in hierarchy
H = 20                      # time horizon to achieve subgoal
lamda = 0.3                 # subgoal testing parameter

# DDPG parameters:
gamma = 0.99                # discount factor for future rewards
n_iter = 200                # update policy n_iter times in one DDPG update
batch_size = 256            # num of transitions sampled from replay buffer
lr = 0.0001

# save trained models
directory = "C:/Users/User/collaborative/DSenv_HAC/Hierarchical-Actor-Critic-HAC-PyTorch/checkpoints/{}/{}level/".format(env_name, k_level) 
filename = "HAC_grip_test"
#########################################################


if random_seed:
    print("Random Seed: {}".format(random_seed))
    env.seed(random_seed)
    torch.manual_seed(random_seed)
    np.random.seed(random_seed)


# creating HAC agent and setting parameters
agent = HAC(k_level, H, state_dim, action_dim, render, threshold, 
            action_bounds, state_bounds,  lr)

agent.set_parameters(lamda, gamma, action_clip_low, action_clip_high, 
                    state_clip_low, state_clip_high, exploration_action_noise, exploration_state_noise)

# logging file:
log_f = open("log.txt","w+")

#Tesnorboard
# writer = SummaryWriter('runs/{}_SAC_{}_{}_{}'.format(datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S"), args.env_name,
                                                            #  args.policy, "autotune" if args.automatic_entropy_tuning else ""))

# Memory
# memory = ReplayBuffer(args.capacity)

# Training Loop
total_numsteps = 0
updates = 0
# joint = np.zeros([4,4])
# joint[0] = np.array([60, 30, 70, 60])
# joint[1] = np.array([32, -20, 30, 150])
# joint[2] = np.array([-10, -10, 80, 90])
# joint[3] = np.array([15, 36, 38, 106])
# for i in range(4):
#     joint[i-1] = np.deg2rad(joint[i-1])
# result = np.zeros([4,3])
# # result[0] = env.check_constraint(joint[0])
# # result[1] = env.check_constraint(joint[1])
# # env.render()
# for i in range(4):
#     result[i] = env.check_constraint(joint[i])
# # print(result)
# si = np.zeros([4,3])

# for j in range(4):
#     si[j][0] = np.cos(joint[j][1])
#     si[j][1] = np.cos(joint[j][1]+joint[j][2])
#     si[j][2] = np.cos(joint[j][1]+joint[j][2]+joint[j][3])

# result = result[:,2]
# print(result)
# si = np.insert(si,0,1,axis=1)
# print(si)
# aa = np.linalg.inv(si)
# print(np.dot(aa,result))


# print(result)

# env.render()
# print(np.rad2deg(0.738), np.rad2deg(0.943))



for i_episode in range(1, max_episodes+1):
    
    agent.reward = 0
    agent.timestep = 0
    
    obs = env.reset()
    state = obs['observation']
    goal_state = obs['desired_goal']
    goal_original_state = obs['desired_goal_original']
    goal_state[3] = 1
    # print("goal{}".format(goal_original_state))
    # print("goal_state : {}".format(goal_original_state))

    # collecting experience in environment
    last_state, done, steps, rew = agent.run_HAC(env, k_level-1, state, goal_state, False)
    total_numsteps+=steps
    # print(last_state, goal_state)

    # goal_achieved = env.clear_goal(last_state, goal_state, 1)
    if rew == 0:
        print("################ Solved! ################ ")
        name = filename + '_solved'
        agent.save(directory, name)
        # lookat[1.88489241e+00 3.03072956e-02 7.19555939e+01]
    
    # update all levels
    agent.update(n_iter, batch_size)
    
    # logging updates:
    log_f.write('{},{}\n'.format(i_episode, agent.reward))
    log_f.flush()
    
    if i_episode % save_episode == 0:
        agent.save(directory, filename)
    
    print("Episode: {}\t Reward: {}\t Total: {} ".format(i_episode, agent.reward, total_numsteps))
