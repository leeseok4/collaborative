import os
import gym
from gym import utils
#from gym.envs.mujoco import mujoco_env
from gym.envs.robotics import fetch_env
from DSenv.gripper.DS_gripper_env import DSGripperEnv
from DSenv.gripper.RG6 import RG6Env
import numpy as np
import DSenv.ds_util as ds_util


# Ensure we get the path separator correct on windows
MODEL_XML_PATH = os.path.join(os.path.abspath(os.path.dirname(__file__)), "RG6pz.xml")

class RG6pzEnv(RG6Env, utils.EzPickle):
    def __init__(self, reward_type='spars'):
        initial_qpos = {
            'joint1': 0, #np.deg2rad(np.random.randint(low=0, high=90)),
            'joint2': 0, #np.deg2rad(np.random.randint(low=35, high=45)),
            'joint3': 1, #np.deg2rad(np.random.randint(low=35, high=45)),
            'joint4': 0,
            'joint5': 1.7, #np.deg2rad(np.random.randint(low=80, high=90)),
            'joint6': 0,
            'base_link_joint': 0,
            'finger_joint': np.deg2rad(0),
            'left_inner_finger_joint': 0,
            # 'left_inner_knuckle_joint': 0,
            'right_outer_knuckle_joint': 0,
            'right_inner_finger_joint': 0,
            # 'right_inner_knuckle_joint': 0,
        }

        self.joint_names = ['joint1', 'joint2', 'joint3', 'joint5', 'finger_joint']
        self.tolerance = 1
        self.pos_limit = [[0.3, -0.1, 0.06], [0.5, 0.1, 0.26]]
        # goal = np.array([0, 0.66, 0.06]) 

        self.jog_delta_limit = 10
        self.max_temp = 1000
        self.is_joint_used_in_obs = True
        self.is_printing_temp = False
        self.n_actions = 4

        DSGripperEnv.__init__(
            self, MODEL_XML_PATH, has_object=True, block_gripper=False, n_substeps=20,
            gripper_extra_height=0.25, target_in_the_air=True, target_offset=0.0,
            obj_range=0.15, target_range=0.15, distance_threshold=0.1,
            initial_qpos=initial_qpos, reward_type=reward_type)
        utils.EzPickle.__init__(self)

    def compute_reward(self, achieved_goal, goal, info):
        # Compute distance between goal and the achieved goal.
        d = ds_util.goal_distance(achieved_goal, goal)
        if self.reward_type == 'sparse':
            return -(d > self.distance_threshold).astype(np.float32)
        else:
            return -d

    def _set_action(self, action):
        assert action.shape == (4,)
        action = action.copy()  
        pos_ctrl, gripper_ctrl = action[:3], action[3]
        pos_ctrl = pos_ctrl * 0.02

        if gripper_ctrl > 0:
            is_joint_action = True

        else:
            is_joint_action = False

        if is_joint_action:
            # Calculate joint action value  
            # pos_ctrl = ds_util.jog_unnormalize(pos_ctrl, lows=[-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit], 
            #                             highs=[self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit])

            cur_pos = self.sim.data.get_mocap_pos('mocap')
            cur_pos[2] = cur_pos[2] #- self.gripper_extra_height
            for i in range(len(cur_pos)):
                tar_pos = cur_pos[i] + pos_ctrl[i]
                tar_pos = np.clip(tar_pos, self.pos_limit[0][i], self.pos_limit[1][i])
                pos_ctrl[i] = tar_pos - cur_pos[i]
            # keep previous gripper action value 
            
            gripper = self.sim.data.get_joint_qpos(self.joint_names[4])

            if gripper > -0.1:
                gripper_ctrl = [1]
            else:
                gripper_ctrl = [-1]

        else:
            # Calculate gripper action value  
            gripper_ctrl = (gripper_ctrl + 0.5) * 2
            #gripper = ds_util.jog_unnormalize([gripper], lows=[-self.jog_delta_limit], highs=[self.jog_delta_limit])
            if gripper_ctrl > 0:
                gripper_ctrl = [1]

            else:
                gripper_ctrl = [-1]

            pos_ctrl = np.array([0 for i in range(3)])



        # # Calculate joint action value  
        # cur_pos = self.sim.data.get_mocap_pos('mocap')
        # cur_pos[2] = cur_pos[2] #- self.gripper_extra_height
        # for i in range(len(cur_pos)):
        #     tar_pos = cur_pos[i] + pos_ctrl[i]
        #     tar_pos = np.clip(tar_pos, self.pos_limit[0][i], self.pos_limit[1][i])
        #     pos_ctrl[i] = tar_pos - cur_pos[i]

        # if is_joint_action:            
        #     # keep previous gripper action value             
        #     gripper = self.sim.data.get_joint_qpos(self.joint_names[4])

        #     if gripper > -0.1:
        #         gripper_ctrl = [1]
        #     else:
        #         gripper_ctrl = [-1]

        # else:
        #     # Calculate gripper action value  
        #     gripper_ctrl = (gripper_ctrl + 0.5) * 2
        #     #gripper = ds_util.jog_unnormalize([gripper], lows=[-self.jog_delta_limit], highs=[self.jog_delta_limit])
        #     if gripper_ctrl > 0:
        #         gripper_ctrl = [1]

        #     else:
        #         gripper_ctrl = [-1]


        # block xy        
        cur_x = self.sim.data.get_mocap_pos('mocap')[0]
        pos_ctrl[0] = 0.4 - cur_x
        cur_y = self.sim.data.get_mocap_pos('mocap')[1]
        pos_ctrl[1] = -cur_y

        self.sim.data.ctrl[0] = gripper_ctrl[0]
        #self.sim.step()

        rot_ctrl = [0., 0., 1., 0.]  # fixed rotation of the end effector, expressed as a quaternion

        action = np.concatenate([pos_ctrl, rot_ctrl, gripper_ctrl])

        # Apply action to simulation.
        ds_util.ctrl_set_action(self.sim, action)
        ds_util.mocap_set_action(self.sim, action)

    def _get_obs(self):
        dt = self.sim.nsubsteps * self.sim.model.opt.timestep

        # obs : gripper pos

        # body_id2 = self.sim.model.body_name2id('right_inner_finger')
        # lookat2 = self.sim.data.body_xpos[body_id2]

        # body_id3 = self.sim.model.body_name2id('left_inner_finger')
        # lookat3 = self.sim.data.body_xpos[body_id3]

        # lookat0 = (lookat2 + lookat3) / 2

        cur_pos = self.sim.data.get_mocap_pos('mocap')
        cur_pos[2] = cur_pos[2] - self.gripper_extra_height

        # achieved_goal : coordinates of object to grip

        body_id = self.sim.model.body_name2id('object0')
        achieved_goal = self.sim.data.body_xpos[body_id]

        #obs = lookat0
        obs = cur_pos

        return {
            'observation': obs.copy(),
            'achieved_goal': achieved_goal.copy(),
            'desired_goal': self.goal.copy(),
        }

    def _render_callback(self):
        # Visualize target.
        sites_offset = (self.sim.data.site_xpos - self.sim.model.site_pos).copy()
        site_id = self.sim.model.site_name2id('target0')
        self.sim.model.site_pos[site_id] = self.goal - sites_offset[0]

        self.sim.forward()

    def _sample_goal(self):
        self.sim.data.set_joint_qpos('joint3', 1)
        self.sim.data.set_joint_qpos('joint5', 2)

        x = 400
        y = 0
        z = np.random.randint(low=210, high=260)

        #goal = np.array([0.5, 0.1, 0.26]) 
        goal = np.array([x / 1000, y / 1000, z / 1000]) 
        #goal = self.initial_gripper_xpos[:3] 
        body_id = self.sim.model.body_name2id('floor0')
        self.sim.data.body_xpos[body_id] = goal
        
        return goal.copy()

    def _is_success(self, achieved_goal, desired_goal):
        d = ds_util.goal_distance(achieved_goal, desired_goal)
        return (d < self.distance_threshold).astype(np.float32)


    def _env_setup(self, initial_qpos):
        for name, value in initial_qpos.items():
            self.sim.data.set_joint_qpos(name, value)

        ds_util.reset_mocap_welds(self.sim)
        self.sim.forward()

        # Move end effector into position.
        #gripper_target = np.array([0, 0.56, 0.46 + self.gripper_extra_height]) #+ self.sim.data.get_site_xpos('robot0:grip')
        gripper_target = np.array([0.5, -0., 0.26]) #+ self.sim.data.get_site_xpos('robot0:grip')
        gripper_rotation = [0., 0., 1., 0.]  # fixed rotation of the end effector, expressed as a quaternion
        #gripper_rotation = np.array([1., 0., 1., 0.])
        self.sim.data.set_mocap_pos('mocap', gripper_target + self.gripper_extra_height)
        self.sim.data.set_mocap_quat('mocap', gripper_rotation)


        pos_ctrl = np.array([0 for i in range(3)])        
        cur_x = self.sim.data.get_mocap_pos('mocap')[0]
        pos_ctrl[0] = 0.4 - cur_x
        cur_y = self.sim.data.get_mocap_pos('mocap')[1]
        pos_ctrl[1] = -cur_y
        cur_z = self.sim.data.get_mocap_pos('mocap')[1]
        pos_ctrl[1] = 0.26 - cur_z

        rot_ctrl = [0., 0., 1., 0.]  # fixed rotation of the end effector, expressed as a quaternion

        action = np.concatenate([pos_ctrl, rot_ctrl, [0]])

        # Apply action to simulation.
        ds_util.ctrl_set_action(self.sim, action)
        ds_util.mocap_set_action(self.sim, action)

        for _ in range(1):
            self.sim.step()

        # Extract information for sampling goals.
        self.initial_gripper_xpos = self.sim.data.get_body_xpos('base_link').copy()
        # if self.has_object:
        #     self.height_offset = self.sim.data.get_site_xpos('object0')[2]