import os, sys
base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
sys.path.append(base_dir)
import gym
import DSenv



# env = gym.make('RG6pos-v0')
# env = gym.make('RG6pz-v0')
# env = gym.make('RG6j-v0')
env = gym.make('RG6sj-v0')

for i_episode in range(1000):

    done = False
    
    obs = env.reset()

    # i = 1

    while not done:
        action = env.action_space.sample()  # Sample random action
        # action[0] = -1
        # action[1] = 0
        # action[2] = -1
        # i = i* -1
        #action[3] = 0.2
        next_obs, reward, done, _ = env.step(action) # Step
        env.render()