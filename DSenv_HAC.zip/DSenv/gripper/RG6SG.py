from asyncio import current_task
import os
from gym import utils
#from gym.envs.mujoco import mujoco_env
from gym.envs.robotics import fetch_env
from DSenv.gripper.DS_gripper_env import DSGripperEnv
import numpy as np
import DSenv.ds_util as ds_util


# Ensure we get the path separator correct on windows
MODEL_XML_PATH = os.path.join(os.path.abspath(os.path.dirname(__file__)), "RG6SG.xml")

class RG6SGEnv(DSGripperEnv, utils.EzPickle):
    def __init__(self, reward_type='sparse'):
        initial_qpos = {
            'joint1': np.deg2rad(-90),
            # 'joint2': np.deg2rad(25),
            'joint2': np.deg2rad(42),
            # 'joint3': np.deg2rad(25),
            'joint3': np.deg2rad(54),
            'joint4': 0,
            # 'joint5': np.deg2rad(60),
            'joint5': np.deg2rad(84),
            'joint6': 0,
            'base_link_joint': 0,
            'finger_joint': 0,
            'left_inner_finger_joint': 0,
            #'left_inner_knuckle_joint': 0,
            'right_outer_knuckle_joint': 0,
            'right_inner_finger_joint': 0,
            #'right_inner_knuckle_joint': 0,
        }
        # self.jog_limit = [[-180, 0, 0, 0], [180, 45, 45, 150]]
        self.joint_names = ['joint1', 'joint2', 'joint3', 'joint5', 'finger_joint']
        
        # full space
        # self.jog_limit = [[-180, 0, 0, 0, -25], [180, 45, 45, 150,0]]
        
        # narrow space
        # self.jog_limit = [[-110, -30, 0, 0, -25], [-70, 75, 160, 160, 0]]
        self.jog_limit = [[-90, -30, 0, -25], [-90, 75, 160, 0]]
        self.j5_limit=[[0],[150]]
        self.tolerance = 1
        self.max_temp = 1000
        self.is_joint_used_in_obs = True
        self.is_printing_temp = False
        self.jog_delta_limit = 30
        self.n_actions = 4
        
        DSGripperEnv.__init__(
            self, MODEL_XML_PATH, has_object=False, block_gripper=True, n_substeps=50,
            gripper_extra_height=0.2, target_in_the_air=True, target_offset=0.0,
            obj_range=0.15, target_range=0.15, distance_threshold=1,
            initial_qpos=initial_qpos, reward_type=reward_type)
        utils.EzPickle.__init__(self)

        # self.distance_threshold_2 = 1
        # self.jog_delta_limit_2 = 1

        


    # GoalEnv methods
    # ----------------------------

    def compute_reward(self, achieved_goal, goal, i_level):
        # Compute distance between goal and the achieved goal.
        #d = goal_distance(achieved_goal, self.normalized_goal)

        # if i_level == 0:
        #     unnormalized_ag = np.array(ds_util.jog_unnormalize(achieved_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
        #     unnormalized_g = np.array(ds_util.jog_unnormalize(goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
        # else:
        #     unnormalized_ag = np.array(ds_util.jog_unnormalize(achieved_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
        #     unnormalized_g = np.array(ds_util.jog_unnormalize(self.normalized_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 

        # d = ds_util.goal_distance(unnormalized_ag, unnormalized_g)

        # grip & place
        lookat0, ob_pos = self.grip_point()
        d = np.linalg.norm(lookat0-ob_pos)
        target_pos = [0.001, -0.6383, 0.2]
        r = -1
        if d < 0.02:
            r=-0.75
        if self.grip_ok:
            r=-0.5
        if self.still:
            r=-0.25
        if self.still and d<0.02 and np.linalg.norm(ob_pos-target_pos) < 0.05:
            r=0

        # if self.reward_type == 'sparse':
        #     d=-(d > 0.01).astype(np.float32)
        #     print
            
        # else:
        #     d=-d
        return r


    # RobotEnv methods
    # ----------------------------

    def _step_callback(self):
        if self.block_gripper:
            self.sim.forward()

    def compute_j5(self,joint):
        # input degree output degree
        j5 = 180-joint[1]-joint[2]
        j5 = np.clip(j5, self.j5_limit[0][0], self.j5_limit[1][0])
        return j5
    
    def grip_point(self):
        site_id2 = self.sim.model.site_name2id('left_dot0')
        left_dot = self.sim.data.site_xpos[site_id2]

        site_id3 = self.sim.model.site_name2id('right_dot0')
        right_dot = self.sim.data.site_xpos[site_id3]

        grip_point = (left_dot + right_dot) / 2
        
        body_id = self.sim.model.body_name2id('object0')
        object_pos = self.sim.data.body_xpos[body_id]

        return grip_point, object_pos

    def check_open(self):
        site_id2 = self.sim.model.site_name2id('left_dot0')
        left_dot = self.sim.data.site_xpos[site_id2]

        site_id3 = self.sim.model.site_name2id('right_dot0')
        right_dot = self.sim.data.site_xpos[site_id3]

        grip_distance = np.linalg.norm(left_dot-right_dot)

        if grip_distance > 0.07:
            return True
        return False

    def check_grip(self, post_gripper, cur_gripper):
        self.grip_ok = False
        lookat0, target = self.grip_point()

        if np.linalg.norm(lookat0-target) < 0.02:
            self.grip_ok = True
        
        if self.grip_ok:
            if not post_gripper:
                self.grip_ok = False
        
        if self.grip_ok:
            if cur_gripper > 0:
                self.grip_ok = False

        return self.grip_ok

    def still_grip(self):
        lookat0, target = self.grip_point()
        open = self.check_open()
        if not open and np.linalg.norm(lookat0-target) <0.01:
            return True
        return False

    def _set_action(self, action):
        assert action.shape == (4,)
        action = action.copy()

        joint_action = action[:3]
        gripper = action[3]
        self.grip_ok = False
        self.still = False
        
        if gripper > 0:
            is_joint_action = True
        else:
            is_joint_action = False
        # is_joint_action = False
        if is_joint_action:
            # only move joints
            # Calculate joint action value  
            joint_action = ds_util.jog_unnormalize(joint_action, lows=[-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit], 
                                        highs=[self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit])
            
            # # keep previous gripper action value  
            # gripper = self.sim.data.get_joint_qpos(self.joint_names[3])

            # obtain current_joints        
            cur_joints = []    
            for i in range(3):
                cur_joints.append(self.sim.data.get_joint_qpos(self.joint_names[i]))
            
            cur_joints = np.array(cur_joints)
            cur_joints = np.rad2deg(cur_joints)

            # add action_joints
            target_joints = cur_joints + joint_action
            
            # set the joint 5
            j5 = self.compute_j5(target_joints)

            # make the joint(j1,2,3) -> joint(j1,2,3,5)
            target_joints = np.append(target_joints, [j5])
            target_joints = np.array(target_joints)
            
            # clip target joints in form of radian.
            target_joints[0] = np.clip(target_joints[0], self.jog_limit[0][0], self.jog_limit[1][0])
            target_joints[1] = np.clip(target_joints[1], self.jog_limit[0][1], self.jog_limit[1][1])
            target_joints[2] = np.clip(target_joints[2], self.jog_limit[0][2], self.jog_limit[1][2])
            target_joints[3] = np.clip(target_joints[3], self.j5_limit[0][0], self.j5_limit[1][0])

            target_joints = np.deg2rad(target_joints)

            # set the target joints to mujoco
            for j in range(len(target_joints)):
                self.sim.data.set_joint_qpos(self.joint_names[j], target_joints[j])
            

        else:
            # only move gripper
            # Calculate gripper action value  
            gripper = (gripper + 0.5) * 2
            if gripper > 0:
                gripper = [1]

            else:
                gripper = [-1]

            # set all joints 0
            for k in range(4):
                self.sim.data.ctrl[k] = 0

            self.sim.data.ctrl[4] = gripper[0]

            post_gripper = self.check_open()
            self.sim.step()
            

            if self.check_grip(post_gripper, gripper[0]):
                self.grip_ok = True
                print("grip!")
                grip_point, _ = self.grip_point()
                ob_pos = np.zeros(7)
                ob_pos[:3] = grip_point
                self.sim.data.set_joint_qpos('object0:joint', ob_pos)
                self.sim.step()

        if self.still_grip():
            self.still = True
            print("still!")
            grip_point, _ = self.grip_point()
            ob_pos = np.zeros(7)
            ob_pos[:3] = grip_point
            self.sim.data.set_joint_qpos('object0:joint', ob_pos)



    def _get_obs(self):
        # positions
        dt = self.sim.nsubsteps * self.sim.model.opt.timestep

        jog1 = self.sim.data.get_joint_qpos('joint1')
        jog2 = self.sim.data.get_joint_qpos('joint2')
        jog3 = self.sim.data.get_joint_qpos('joint3')
        # jog5 = self.sim.data.get_joint_qpos('joint5')
        gripper = self.sim.data.get_joint_qpos('finger_joint')

        cur_jog = np.array((jog1, jog2, jog3, gripper))
        cur_jog = np.rad2deg(cur_jog)
        goal_state = [-1.57, 0.738, 0.503, 0]
        goal_state1 = np.rad2deg(goal_state)
        goal_state = np.array(ds_util.jog_normalize(goal_state1,lows=self.jog_limit[0], highs=self.jog_limit[1]))

        cur_jog1 = np.array(ds_util.jog_normalize(cur_jog, lows=self.jog_limit[0], highs=self.jog_limit[1]))        

        achieved_goal = cur_jog1.copy()

        obs1 = np.concatenate([cur_jog1])
        obs = np.concatenate([cur_jog])

        return {
            'observation': obs1.copy(),
            'observation_original': obs.copy(),
            'achieved_goal': achieved_goal.copy(),
            'desired_goal': goal_state.copy(),
            'desired_goal_original' : goal_state1.copy(),
        }
        

    def _viewer_setup(self):
        body_id = self.sim.model.body_name2id('link6')
        lookat = self.sim.data.body_xpos[body_id]
        for idx, value in enumerate(lookat):
            self.viewer.cam.lookat[idx] = value
        self.viewer.cam.distance = 2.5
        self.viewer.cam.azimuth = 132.
        self.viewer.cam.elevation = -14.

    def check_constraint(self, joint):
        self.sim.data.set_joint_qpos('joint1', joint[0])
        self.sim.data.set_joint_qpos('joint2', joint[1])
        self.sim.data.set_joint_qpos('joint3', joint[2])
        self.sim.data.set_joint_qpos('joint5', joint[3])
        self.sim.step()

        body_id2 = self.sim.model.body_name2id('right_inner_finger')
        lookat2 = self.sim.data.body_xpos[body_id2]

        body_id3 = self.sim.model.body_name2id('left_inner_finger')
        lookat3 = self.sim.data.body_xpos[body_id3]
        lookat0 = (lookat2 + lookat3) / 2

        # if lookat0[2] > 0.02: 
        #     a = True
        # else:
            # a = False
        return lookat0

    def _render_callback(self):
        # Visualize target.

        jog1 = self.sim.data.get_joint_qpos('joint1')
        jog2 = self.sim.data.get_joint_qpos('joint2')
        jog3 = self.sim.data.get_joint_qpos('joint3')
        jog5 = self.sim.data.get_joint_qpos('joint5')


        # self.sim.data.set_joint_qpos('joint1', 0)
        # self.sim.data.set_joint_qpos('joint2', 0)
        # self.sim.data.set_joint_qpos('joint3', 0)
        # self.sim.data.set_joint_qpos('joint5', 0)
        # self.sim.step()

        body_id2 = self.sim.model.body_name2id('right_inner_finger')
        lookat2 = self.sim.data.body_xpos[body_id2]

        body_id3 = self.sim.model.body_name2id('left_inner_finger')
        lookat3 = self.sim.data.body_xpos[body_id3]

        lookat0 = (lookat2 + lookat3) / 2
        # print("lookat{}".format(lookat0))

        # self.sim.data.set_joint_qpos('joint1', jog1)
        # self.sim.data.set_joint_qpos('joint2', jog2)
        # self.sim.data.set_joint_qpos('joint3', jog3)
        # self.sim.data.set_joint_qpos('joint5', jog5)
        # self.sim.step()
            
        sites_offset = (self.sim.data.site_xpos - self.sim.model.site_pos).copy()
        site_id = self.sim.model.site_name2id('target0')
        # self.sim.model.site_pos[site_id] = lookat0 - sites_offset[0]
        self.sim.model.site_pos[site_id] = lookat0
        # print(self.sim.model.site_pos[site_id])
        # self.sim.forward()


    def _reset_sim(self):
        self.sim.set_state(self.initial_state)
        # Randomize start position of object.
        if self.has_object:
            object_xpos = self.initial_gripper_xpos[:2]
            while np.linalg.norm(object_xpos - self.initial_gripper_xpos[:2]) < 0.1:
                object_xpos = self.initial_gripper_xpos[:2] + self.np_random.uniform(-self.obj_range, self.obj_range, size=2)
            object_qpos = self.sim.data.get_joint_qpos('object0:joint')
            assert object_qpos.shape == (7,)
            object_qpos[:2] = object_xpos
            self.sim.data.set_joint_qpos('object0:joint', object_qpos)

        self.sim.forward()
        return True

    def _sample_goal(self):
        if self.has_object:
            goal = self.initial_gripper_xpos[:3] + self.np_random.uniform(-self.target_range, self.target_range, size=3)
            goal += self.target_offset
            goal[2] = self.height_offset
            if self.target_in_the_air and self.np_random.uniform() < 0.5:
                goal[2] += self.np_random.uniform(0, 0.45)
        else:
            # j1 = np.random.randint(low=self.jog_limit[0][0], high=self.jog_limit[1][0])
            # j2 = np.random.randint(low=self.jog_limit[0][1], high=self.jog_limit[1][1])
            # j3 = np.random.randint(low=self.jog_limit[0][2], high=self.jog_limit[1][2])
            # j5 = np.random.randint(low=self.jog_limit[0][3], high=self.jog_limit[1][3])
            j1 = np.deg2rad(60)
            j2 = np.deg2rad(60)
            j3 = np.deg2rad(60)
            # j5 = np.deg2rad(0)
            gripper = 0
            #gripper = np.random.randint(low=self.jog_limit[0][3], high=self.jog_limit[1][3])
            #goal = np.array([j1,j2,j3,j5,gripper])
            goal = np.array([j1,j2,j3,gripper])
            self.goal = goal
            self.normalized_goal = np.array(ds_util.jog_normalize(goal, lows=self.jog_limit[0], highs=self.jog_limit[1]))

        return goal.copy()

    def _is_success(self, achieved_goal, desired_goal):
        d = ds_util.goal_distance(achieved_goal, desired_goal)
        return (d < self.distance_threshold).astype(np.float32)

    def clear_goal(self, achieved_goal, goal, i_level):
        
        if i_level == 0:
            unnormalized_ag = np.array(ds_util.jog_unnormalize(achieved_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
            unnormalized_g = np.array(ds_util.jog_unnormalize(goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
        else:
            unnormalized_ag = np.array(ds_util.jog_unnormalize(achieved_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
            unnormalized_g = np.array(ds_util.jog_unnormalize(self.normalized_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 

        d = ds_util.goal_distance(unnormalized_ag, unnormalized_g)
        return (d < self.distance_threshold).astype(np.float32)
        

    def _env_setup(self, initial_qpos):
        for name, value in initial_qpos.items():
            self.sim.data.set_joint_qpos(name, value)
        #utils.reset_mocap_welds(self.sim)
        self.sim.forward()

        # Move end effector into position.
        #gripper_target = np.array([-0.498, 0.005, -0.431 + self.gripper_extra_height]) + self.sim.data.get_site_xpos('robot0:grip')
        #gripper_rotation = np.array([1., 0., 1., 0.])
        #self.sim.data.set_mocap_pos('robot0:mocap', gripper_target)
        #self.sim.data.set_mocap_quat('robot0:mocap', gripper_rotation)
        for _ in range(10):
            self.sim.step()

        # Extract information for sampling goals.
        #self.initial_gripper_xpos = self.sim.data.get_site_xpos('robot0:grip').copy()
        #if self.has_object:
        #    self.height_offset = self.sim.data.get_site_xpos('object0')[2]

    def render(self, mode='human', width=500, height=500):
        return super(RG6SGEnv, self).render(mode, width, height)