import os
from gym import utils
#from gym.envs.mujoco import mujoco_env
from gym.envs.robotics import fetch_env
from DSenv import DS_env
import numpy as np
import DSenv.ds_util as ds_util


# Ensure we get the path separator correct on windows
MODEL_XML_PATH = os.path.join(os.path.abspath(os.path.dirname(__file__)), "a0509pos.xml")

class a0509posEnv(DS_env.DSEnv, utils.EzPickle):
    def __init__(self, reward_type='spars'):
        initial_qpos = {
            'joint1': 0,
            'joint2': 0,
            'joint3': 0,
            'joint4': 0,
            'joint5': 0,
            'joint6': 0,
        }
        
        self.jog_limit = [[-180, 0, 0, 0], [180, 45, 45, 90]]

        self.jog_delta_limit = 10

        DS_env.DSEnv.__init__(
            self, MODEL_XML_PATH, has_object=False, block_gripper=True, n_substeps=20,
            gripper_extra_height=0.2, target_in_the_air=True, target_offset=0.0,
            obj_range=0.15, target_range=0.15, distance_threshold=0.1,
            initial_qpos=initial_qpos, reward_type=reward_type)
        utils.EzPickle.__init__(self)


    def compute_reward(self, achieved_goal, goal, info):
        # Compute distance between goal and the achieved goal.

        d = ds_util.goal_distance(achieved_goal, self.goal)
        if self.reward_type == 'sparse':
            return -(d > self.distance_threshold).astype(np.float32)
        else:
            return -d


    def _set_action(self, action):
        assert action.shape == (4,)
        action = action.copy()  # ensure that we don't change the action outside of this scope

        # Apply action to simulation.
        action = np.concatenate((action, [0]), axis=-1)
        action = ds_util.jog_unnormalize(action, lows=[-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit], 
                                        highs=[self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit])
        #action = jog_unnormalize(action, lows=self.jog_limit[0], highs=self.jog_limit[1])

        action = action[:4]
        action = np.array(action)

        state = self.sim.get_state()
        cur_jog = state.qpos
        cur_jog = np.rad2deg(cur_jog)
        cur_jog = np.array([cur_jog[0], cur_jog[1], cur_jog[2], cur_jog[4]])

        cur_jog += action
        cur_jog[0] = np.clip(cur_jog[0], self.jog_limit[0][0], self.jog_limit[1][0])
        cur_jog[1] = np.clip(cur_jog[1], self.jog_limit[0][1], self.jog_limit[1][1])
        cur_jog[2] = np.clip(cur_jog[2], self.jog_limit[0][2], self.jog_limit[1][2])
        cur_jog[3] = np.clip(cur_jog[3], self.jog_limit[0][3], self.jog_limit[1][3])

        #clipped_sum_jog = np.deg2rad(clipped_sum_jog)
        clipped_sum_jog = np.deg2rad(cur_jog)
        
        #print(self.sim.data.get_joint_xpos('joint6'))

        self.sim.data.set_joint_qpos('joint1', clipped_sum_jog[0])
        self.sim.data.set_joint_qpos('joint2', clipped_sum_jog[1])
        self.sim.data.set_joint_qpos('joint3', clipped_sum_jog[2])
        self.sim.data.set_joint_qpos('joint5', clipped_sum_jog[3])

    def _get_obs(self):
        # positions
        dt = self.sim.nsubsteps * self.sim.model.opt.timestep

        body_id = self.sim.model.body_name2id('link6')
        lookat = self.sim.data.body_xpos[body_id]

        jog1 = self.sim.data.get_joint_qpos('joint1')
        jog2 = self.sim.data.get_joint_qpos('joint2')
        jog3 = self.sim.data.get_joint_qpos('joint3')
        jog5 = self.sim.data.get_joint_qpos('joint5')

        cur_jog = np.array((jog1, jog2, jog3, jog5))
        cur_jog = np.rad2deg(cur_jog)

        #print(cur_jog, self.goal)

        cur_jog = np.array(ds_util.jog_normalize(cur_jog, lows=self.jog_limit[0], highs=self.jog_limit[1]))        

        achieved_goal = lookat.copy()

        obs = np.concatenate([
            cur_jog
        ])

        return {
            'observation': obs.copy(),
            'achieved_goal': achieved_goal.copy(),
            'desired_goal': self.goal,
            #'desired_goal': self.goal.copy(),
        }

    def _render_callback(self):
        # Visualize target.            
        sites_offset = (self.sim.data.site_xpos - self.sim.model.site_pos).copy()
        site_id = self.sim.model.site_name2id('target0')
        self.sim.model.site_pos[site_id] = self.goal - sites_offset[0]
        self.sim.forward()

    def _reset_sim(self):
        self.sim.set_state(self.initial_state)

        self.sim.forward()
        return True

    def _sample_goal(self):
        j1 = np.random.randint(low=self.jog_limit[0][0], high=self.jog_limit[1][0])
        j2 = np.random.randint(low=self.jog_limit[0][1], high=self.jog_limit[1][1])
        j3 = np.random.randint(low=self.jog_limit[0][2], high=self.jog_limit[1][2])
        j5 = np.random.randint(low=self.jog_limit[0][3], high=self.jog_limit[1][3])

        jog1 = self.sim.data.get_joint_qpos('joint1')
        jog2 = self.sim.data.get_joint_qpos('joint2')
        jog3 = self.sim.data.get_joint_qpos('joint3')
        jog5 = self.sim.data.get_joint_qpos('joint5')

        self.sim.data.set_joint_qpos('joint1', np.deg2rad(j1))
        self.sim.data.set_joint_qpos('joint2', np.deg2rad(j2))
        self.sim.data.set_joint_qpos('joint3', np.deg2rad(j3))
        self.sim.data.set_joint_qpos('joint5', np.deg2rad(j5))
        self.sim.step()

        body_id = self.sim.model.body_name2id('link6')
        lookat = self.sim.data.body_xpos[body_id]
        goal = np.array(lookat)
        self.goal = goal

        self.sim.data.set_joint_qpos('joint1', jog1)
        self.sim.data.set_joint_qpos('joint2', jog2)
        self.sim.data.set_joint_qpos('joint3', jog3)
        self.sim.data.set_joint_qpos('joint5', jog5)
        self.sim.step()
            
        return goal.copy()
