import torch
import numpy as np
from DDPG import DDPG
from utils import ReplayBuffer
import DSenv

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class HAC:
    def __init__(self, k_level, H, state_dim, action_dim, render, threshold, 
                 action_bounds, state_bounds, lr):
        
        # adding lowest level
        
        self.HAC = [DDPG(state_dim, action_dim, action_bounds, lr, H)]
        
        # adding remaining levels
        for _ in range(k_level-1):
            self.HAC.append(DDPG(state_dim, state_dim, state_bounds, lr, H))
            
        
        # set some parameters
        self.k_level = k_level
        self.H = H
        self.action_dim = action_dim
        self.state_dim = state_dim
        self.threshold = threshold
        self.render = render
        
        # logging parameters
        self.goals = [None]*self.k_level
        self.reward = 0
        self.timestep = 0
        
    def set_parameters(self, lamda, gamma, action_clip_low, action_clip_high, 
                       state_clip_low, state_clip_high, exploration_action_noise, exploration_state_noise):
        
        self.lamda = lamda
        self.gamma = gamma
        self.action_clip_low = action_clip_low
        self.action_clip_high = action_clip_high
        self.state_clip_low = state_clip_low
        self.state_clip_high = state_clip_high
        self.exploration_action_noise = exploration_action_noise
        self.exploration_state_noise = exploration_state_noise


    def run_HAC(self, env, i_level, state, goal, is_subgoal_test):
        next_state = None
        done = None
        goal_transitions = []
        # logging updates
        self.goals[i_level] = goal
       
        if i_level==1:
            self.ultimate_goal=goal
           
        if i_level==1:
            self.steps=0
            
        # H attempts
        for _ in range(self.H):
            
            action = self.HAC[i_level].select_action(state,goal)
                        
            #   <================ high level policy ================>
            if i_level > 0:
            
                next_state, done, self.steps = self.run_HAC(env, i_level-1, state, action, _)

                goal_achieved = env.clear_goal(next_state, goal, i_level)
                if goal_achieved:
                    done = True
                
            #   <================ low level policy ================>
            else:
                
                next_state, rew, done, _ = env.step(action)
                next_state = next_state['observation']
                done = env.clear_goal(next_state,self.ultimate_goal,i_level)
                
                goal_achieved = env.clear_goal(next_state, goal, i_level)
                self.steps +=1
                
            env.render()    
            state = next_state

            if goal_achieved or done:
                break            
         
        return next_state, done, self.steps
    
    
    def update(self, n_iter, batch_size):
        for i in range(self.k_level):
            self.HAC[i].update(self.replay_buffer[i], n_iter, batch_size)
    
    
    def save(self, directory, name):
        for i in range(self.k_level):
            self.HAC[i].save(directory, name+'_level_{}'.format(i))
    
    
    def load(self, directory, name):
        for i in range(self.k_level):
            self.HAC[i].load(directory, name+'_level_{}'.format(i))
    
        
        
        
        
        
