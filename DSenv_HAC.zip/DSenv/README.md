# DSenv
MuJoCo extension for DooSan collaboratory robot arm

How to connect DSenv to VsCode

0. Prerequisite

* Install VsCode.

- If using Window, click "Download Git for Windows" at third button, left tab in VsCode.

![image](https://user-images.githubusercontent.com/108254699/176345333-38efca75-34d3-4417-878a-ccbf47d16d78.png)

- If using Mac, click "Download Git for macOS" instead.


* Github account and admission of teamproject.


* Library Requirements for virtual environment

- free-mujoco-py==2.1.6

- gym==0.15.4

- gym3==0.3.3


1. Git clone

- Press F1 and type 'git clone' at popped textbox.

- Copy following address(this project address)

https://github.com/ConOptLab/DSenv

![image](https://user-images.githubusercontent.com/108254699/176345935-f671a8c0-b053-4875-9ec1-55c8e4d034cd.png)

- Select directories to clone project to.

![image](https://user-images.githubusercontent.com/108254699/176346027-dbffa7fe-e176-41a4-a3e7-0600ccadc63c.png)


2. Github account authontification

- At terminal(if using Window, at Powershell), type following command.
 
git config --global user.name “own github account name”

git config --global user.email “own github account mail address”

3. Simulate

- You can always simulate DooSan MuJoCo environment by launching 'rendering_example.py' script.


