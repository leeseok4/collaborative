from fileinput import filename
import os, sys
base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
sys.path.append(base_dir)
import argparse
import datetime
import gym
import numpy as np
import itertools
import torch
from HAC_test import HAC
from torch.utils.tensorboard import SummaryWriter
from utils import ReplayBuffer

import DSenv
from gym.envs.robotics.fetch.reach import FetchReachEnv

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

parser = argparse.ArgumentParser(description='PyTorch Soft Actor-Critic Args')
parser.add_argument('--env-name', default="FetchReach-v1",
                    help='Mujoco Gym environment (default: HalfCheetah-v2)')
parser.add_argument('--policy', default="Gaussian",

                    help='Policy Type: Gaussian | Deterministic (default: Gaussian)')
parser.add_argument('--eval', type=bool, default=True,
                    help='Evaluates a policy a policy every 10 episode (default: True)')
parser.add_argument('--gamma', type=float, default=0.99, metavar='G',
                    help='discount factor for reward (default: 0.99)')
parser.add_argument('--tau', type=float, default=0.005, metavar='G',
                    help='target smoothing coefficient(τ) (default: 0.005)')
parser.add_argument('--lr', type=float, default=0.0003, metavar='G',
                    help='learning rate (default: 0.0003)')
parser.add_argument('--alpha', type=float, default=0.2, metavar='G',
                    help='Temperature parameter α determines the relative importance of the entropy\
                            term against the reward (default: 0.2)')
parser.add_argument('--automatic_entropy_tuning', type=bool, default=True, metavar='G',
                    help='Automaically adjust α (default: False)')
parser.add_argument('--seed', type=int, default=123456, metavar='N',
                    help='random seed (default: 123456)')
parser.add_argument('--batch_size', type=int, default=256, metavar='N',
                    help='batch size (default: 256)')
parser.add_argument('--num_steps', type=int, default=10000001, metavar='N',
                    help='maximum number of steps (default: 1000000)')
parser.add_argument('--hidden_size', type=int, default=256, metavar='N',
                    help='hidden size (default: 256)')
parser.add_argument('--updates_per_step', type=int, default=1, metavar='N',
                    help='model updates per simulator step (default: 1)')
parser.add_argument('--start_steps', type=int, default=10000, metavar='N',
                    help='Steps sampling random actions (default: 10000)')
parser.add_argument('--target_update_interval', type=int, default=1, metavar='N',
                    help='Value target update per no. of updates per step (default: 1)')
parser.add_argument('--capacity', type=int, default=1000000, metavar='N',
                    help='size of replay buffer (default: 10000000)')
parser.add_argument('--cuda', action="store_true",
                    help='run on CUDA (default: False)')
args = parser.parse_args()


# checkpoint_name = 'f5'

args.cuda = False
render = False
env_name = 'RG6SG-v0'
env = gym.make('RG6SG-v0')
#env = gym.make('RG6-v0')

env.seed(args.seed)
env.action_space.seed(args.seed)

torch.manual_seed(args.seed)
np.random.seed(args.seed)

save_episode = 20                   # keep saving every n episodes
max_episodes = 10000000             # max num of training episodes
random_seed = 0

state_dim = 5
action_dim = env.action_space.shape[0]

"""
    Actions (both primitive and subgoal) are implemented as follows:
    action = ( network output (Tanh) * bounds ) + offset
    clip_high and clip_low bound the exploration noise
"""
# primitive action bounds and offset
# action_bounds = env.action_space.high[0]
action_bounds_np = np.array([1,1,1,1,0])
action_bounds = torch.FloatTensor(action_bounds_np.reshape(1, -1)).to(device)

# action_offset = np.array([0.0])
# action_offset = torch.FloatTensor(action_offset.reshape(1, -1)).to(device)
# action_clip_low = np.array([-1.0 * action_bounds])
# action_clip_high = np.array([action_bounds])
action_clip_low = np.array([-1, -1, -1, -1, 1])
action_clip_high = np.array([1, 1, 1, 1, -1])


# state bounds and offset
state_bounds_np = np.array([1,1,1,1,0])
state_bounds = torch.FloatTensor(state_bounds_np.reshape(1, -1)).to(device)
# state_offset =  np.array([-0.3, 0.0])
# state_offset = torch.FloatTensor(state_offset.reshape(1, -1)).to(device)
state_clip_low = np.array([-1, -1, -1, -1, 1])
state_clip_high = np.array([1, 1, 1, 1, -1])

# exploration noise std for primitive action and subgoals
# exploration_action_noise = np.array([0.1])        
exploration_action_noise = 0.1        
exploration_state_noise = np.array([0.02, 0.01]) 

# goal_state = np.array([0.48, 0.04])        # final goal state to be achived
threshold = np.array([0.5, 0.5, 0.5, 0.5, 0])         # threshold value to check if goal state is achieved

# HAC parameters:
k_level = 2                 # num of levels in hierarchy
H = 20                      # time horizon to achieve subgoal
lamda = 0.3                 # subgoal testing parameter

# DDPG parameters:
gamma = 0.99                # discount factor for future rewards
n_iter = 200                # update policy n_iter times in one DDPG update
batch_size = 256            # num of transitions sampled from replay buffer
lr = 0.0001

# save trained models
directory = "C:/Users/User/collaborative/DSenv_HAC/Hierarchical-Actor-Critic-HAC-PyTorch/checkpoints/{}/{}level/".format(env_name, k_level) 
# filename = "HAC_{} threshold:5".format(env_name)
filename = "HAC_grip"
#########################################################


if random_seed:
    print("Random Seed: {}".format(random_seed))
    env.seed(random_seed)
    torch.manual_seed(random_seed)
    np.random.seed(random_seed)

# creating HAC agent and setting parameters
agent = HAC(k_level, H, state_dim, action_dim, render, threshold, 
            action_bounds, state_bounds,  lr)

agent.set_parameters(lamda, gamma, action_clip_low, action_clip_high, 
                    state_clip_low, state_clip_high, exploration_action_noise, exploration_state_noise)

# load agent
agent.load(directory, filename)

# Training Loop
total_numsteps = 0
updates = 0


for i_episode in range(100):
    
    agent.reward = 0
    agent.timestep = 0
    
    obs = env.reset()
    state = obs['observation']
    goal_state = obs['desired_goal']
    
    # goal_original_state = obs['desired_goal_original']
    last_state, done, steps = agent.run_HAC(env, k_level-1, state, goal_state, False)
    
    goal_achieved = env.clear_goal(last_state, goal_state, 1)
    if goal_achieved == True:
        print("################ Solved! ################ ")

    # print(last_state, goal_state)

    print("Episode: {}\t Reward: {}".format(i_episode, agent.reward))

env.close()
