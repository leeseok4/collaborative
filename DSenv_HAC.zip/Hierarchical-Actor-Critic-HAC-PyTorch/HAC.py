import torch
import numpy as np
from DDPG import DDPG
from utils import ReplayBuffer
import DSenv

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class HAC:
    def __init__(self, k_level, H, state_dim, action_dim, render, threshold, 
                 action_bounds, state_bounds, lr):
        
        # adding lowest level
        capacity = 100000
        self.HAC = [DDPG(state_dim, action_dim, action_bounds, lr, H)]
        self.replay_buffer = [ReplayBuffer(capacity)]
        
        # adding remaining levels
        for _ in range(k_level-1):
            self.HAC.append(DDPG(state_dim, state_dim, state_bounds, lr, H))
            self.replay_buffer.append(ReplayBuffer(capacity))
        
        # set some parameters
        self.k_level = k_level
        self.H = H
        self.action_dim = action_dim
        self.state_dim = state_dim
        self.threshold = threshold
        self.render = render
        
        # logging parameters
        self.goals = [None]*self.k_level
        self.reward = 0
        self.timestep = 0
        
    def set_parameters(self, lamda, gamma, action_clip_low, action_clip_high, 
                       state_clip_low, state_clip_high, exploration_action_noise, exploration_state_noise):
        
        self.lamda = lamda
        self.gamma = gamma
        self.action_clip_low = action_clip_low
        self.action_clip_high = action_clip_high
        self.state_clip_low = state_clip_low
        self.state_clip_high = state_clip_high
        self.exploration_action_noise = exploration_action_noise
        self.exploration_state_noise = exploration_state_noise

    
    
    
    # def check_goal(self, state_original, goal_original):
    #     if np.linalg.norm(state_original-goal_original, axis=-1) > 10:
    #         return False
    #     return True    
    def check_goal(self,reward):
        if reward == 0: 
            return True
        return False


    def run_HAC(self, env, i_level, state, goal, is_subgoal_test):
        next_state = None
        done = None
        goal_transitions = []
        # logging updates
        self.goals[i_level] = goal
        a=0
        
        if i_level==1:
            self.ultimate_goal=goal
            # print(self.ultimate_goal,"1")
        if i_level==1:
            self.steps=0
            # print(self.ultimate_goal,"1")    
        
        # H attempts
        for _ in range(self.H):
            
            # if this is a subgoal test, then next/lower level goal has to be a subgoal test
            is_next_subgoal_test = is_subgoal_test
            action = self.HAC[i_level].select_action(state,goal)
            # print("i : {}".format(i_level))
            
            
            #   <================ high level policy ================>
            if i_level > 0:
                # add noise or take random action if not subgoal testing (generate sub_goal)
                if not is_subgoal_test:
                    if np.random.random_sample() > 0.2:
                        noise = np.random.normal(0, 0.05, size=4)
                        action = action + noise
                        action = action.clip(self.state_clip_low, self.state_clip_high)
                    else:
                        action = np.random.uniform(self.state_clip_low, self.state_clip_high)
                        

                # Determine whether to test subgoal (action)
                if np.random.random_sample() < self.lamda:
                    is_next_subgoal_test = True
                
                # print("level:{} state:{},goal:{}".format(i_level+1,state,goal))
                # Pass subgoal to lower level 
                next_state, done, self.steps = self.run_HAC(env, i_level-1, state, action, is_next_subgoal_test)

                
                goal_achieved = env.clear_goal(action, next_state, i_level-1)
                # if subgoal was tested but not achieved, add subgoal testing transition
                if is_next_subgoal_test and not goal_achieved:
                    self.replay_buffer[i_level].add((state, action, -self.H, next_state, goal, 0.0, float(done)))
                
                # for hindsight action transition
                action = next_state
                goal_achieved = env.clear_goal(next_state, goal, i_level)
                if goal_achieved == True:
                    done = True
                
            #   <================ low level policy ================>
            else:
                # add noise or take random action if not subgoal testing
                if not is_subgoal_test:
                    if np.random.random_sample() > 0.2:
                        action = action + np.random.normal(0, 0.1, size=len(action))
                        action = action.clip(self.action_clip_low, self.action_clip_high)
                    else:
                        action = np.random.uniform(self.action_clip_low, self.action_clip_high, size=4)
                
                # take primitive action
                
                next_state, rew, done, _ = env.step(action)
                next_state = next_state['observation']
                done = env.clear_goal(next_state,self.ultimate_goal,i_level)
                # print(self.ultimate_goal,"2")
                
                env.render()
                
                if self.render:
                    if self.k_level == 2:
                        env.unwrapped.render_goal(self.goals[0], self.goals[1])
                    elif self.k_level == 3:
                        env.unwrapped.render_goal_2(self.goals[0], self.goals[1], self.goals[2])
                    
                                
                # this is for logging
                self.reward += rew
                self.timestep +=1
                goal_achieved = env.clear_goal(next_state, goal, i_level)
                self.steps +=1
                # if goal_achieved:
                    # print(done,"2")

            
            #   <================ finish one step/transition ================>
            
            # check if goal is achieved
            
            # goal_achieved = self.check_goal(next_state, goal, self.threshold)
         

            # hindsight action transition
            if goal_achieved:
                self.replay_buffer[i_level].add((state, action, 0.0, next_state, goal, 0.0, float(done)))
                # print("level:{} done:{}".format(i_level,done))
            else:
                self.replay_buffer[i_level].add((state, action, -1.0, next_state, goal, self.gamma, float(done)))
              
               
            # copy for goal transition
            goal_transitions.append([state, action, -1.0, next_state, None, self.gamma, float(done)])
            
            a += 1
            state = next_state

            if goal_achieved or done:
                break            
            
        
        
        #   <================ finish H attempts ================>
        
        # hindsight goal transition
        # last transition reward and discount is 0
        goal_transitions[-1][2] = 0.0
        goal_transitions[-1][5] = 0.0
        # print(goal_transitions,"1")
        for transition in goal_transitions:
            # last state is goal for all transitions
            transition[4] = next_state
            # print(transition,"transition")
            self.replay_buffer[i_level].add(tuple(transition))


        return next_state, done, self.steps
    
    
    def update(self, n_iter, batch_size):
        for i in range(self.k_level):
            self.HAC[i].update(self.replay_buffer[i], n_iter, batch_size)
    
    
    def save(self, directory, name):
        for i in range(self.k_level):
            self.HAC[i].save(directory, name+'_level_{}'.format(i))
    
    
    def load(self, directory, name):
        for i in range(self.k_level):
            self.HAC[i].load(directory, name+'_level_{}'.format(i))
    
        
        
        
        
        
