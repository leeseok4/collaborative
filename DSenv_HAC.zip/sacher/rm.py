import os, sys
base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
sys.path.append(base_dir)
import argparse
import datetime
import gym
import numpy as np
import itertools
import torch
from sacher.sac import SAC
#from torch.utils.tensorboard import SummaryWriter
from sacher.replay_memory import ReplayMemory

import environments
from gym.envs.robotics.fetch.reach import FetchReachEnv

parser = argparse.ArgumentParser(description='PyTorch Soft Actor-Critic Args')
parser.add_argument('--env-name', default="FetchReach-v1",
                    help='Mujoco Gym environment (default: HalfCheetah-v2)')
parser.add_argument('--policy', default="Gaussian",
                    help='Policy Type: Gaussian | Deterministic (default: Gaussian)')
parser.add_argument('--eval', type=bool, default=True,
                    help='Evaluates a policy a policy every 10 episode (default: True)')
parser.add_argument('--gamma', type=float, default=0.99, metavar='G',
                    help='discount factor for reward (default: 0.99)')
parser.add_argument('--tau', type=float, default=0.005, metavar='G',
                    help='target smoothing coefficient(τ) (default: 0.005)')
parser.add_argument('--lr', type=float, default=0.0003, metavar='G',
                    help='learning rate (default: 0.0003)')
parser.add_argument('--alpha', type=float, default=0.2, metavar='G',
                    help='Temperature parameter α determines the relative importance of the entropy\
                            term against the reward (default: 0.2)')
parser.add_argument('--automatic_entropy_tuning', type=bool, default=True, metavar='G',
                    help='Automaically adjust α (default: False)')
parser.add_argument('--seed', type=int, default=123456, metavar='N',
                    help='random seed (default: 123456)')
parser.add_argument('--batch_size', type=int, default=256, metavar='N',
                    help='batch size (default: 256)')
parser.add_argument('--num_steps', type=int, default=10000001, metavar='N',
                    help='maximum number of steps (default: 1000000)')
parser.add_argument('--hidden_size', type=int, default=256, metavar='N',
                    help='hidden size (default: 256)')
parser.add_argument('--updates_per_step', type=int, default=1, metavar='N',
                    help='model updates per simulator step (default: 1)')
parser.add_argument('--start_steps', type=int, default=500, metavar='N',
                    help='Steps sampling random actions (default: 10000)')
parser.add_argument('--target_update_interval', type=int, default=1, metavar='N',
                    help='Value target update per no. of updates per step (default: 1)')
parser.add_argument('--replay_size', type=int, default=1000000, metavar='N',
                    help='size of replay buffer (default: 10000000)')
parser.add_argument('--cuda', action="store_true", default=True,
                    help='run on CUDA (default: False)')
args = parser.parse_args()


checkpoint_name = 'grip_180_20_10'
#checkpoint_name = 'temp'

num_envs=50

args.cuda = True

# Environment
#env = gym.make('RG6-v0')
envs = gym.vector.make('DSReach-v0', num_envs)

envs.seed(args.seed)
envs.action_space.seed(args.seed)

torch.manual_seed(args.seed)
np.random.seed(args.seed)

# Agent
#agent = SAC(8, env.action_space, args)
agent = SAC(8, envs.action_space[0], args)
#agent = SAC(env.observation_space.shape[0], env.action_space, args)

# Memory
memory = ReplayMemory(args.replay_size, args.seed)

# Training Loop
i_episode = 0

total_numsteps = 0
updates = 0

episode_reward = 0
episode_steps = [0 for i in range(num_envs)]

obs = envs.reset()
state = np.concatenate((obs['observation'], obs['desired_goal']), axis=-1)

while True:
    if args.start_steps > total_numsteps:
        action = envs.action_space.sample()  # Sample random action
    else:
        action = np.ones((num_envs, 4))

        for i in range(num_envs):
            action[i] = (agent.select_action(state[i]))  # Sample action from policy

    if len(memory) > args.batch_size:
        # Number of updates per step in environment
        for i in range(num_envs):
            # Update parameters of all the networks
            critic_1_loss, critic_2_loss, policy_loss, ent_loss, alpha = agent.update_parameters(memory, args.batch_size, updates)

            updates += num_envs

    next_obs, reward, done, _ = envs.step(action) # Step
    default_next_state = np.concatenate((next_obs['observation'], next_obs['desired_goal']), axis=-1)
    #print(next_obs['observation'])
    episode_steps = np.add(episode_steps, [1 for i in range(num_envs)]) 
    total_numsteps += 5
    episode_reward += reward

    for i in range(num_envs):
        
        mask = 1 if episode_steps[i] == 50 else float(not done[i])        

        memory.push(state[i], action[i], reward[i], default_next_state[i], mask) # Append transition to memory

        her_state = np.concatenate((obs['observation'][i], next_obs['achieved_goal'][i]), axis=-1)
        her_next_state = np.concatenate((next_obs['observation'][i], next_obs['achieved_goal'][i]), axis=-1)
        memory.her_push(her_state, action[i], 0, her_next_state, 0) # Append transition to memory

        if done[i]:
            #default_next_state[i] = np.concatenate((obs['observation'][i], obs['desired_goal'][i]), axis=-1)
            print("Episode: {}, total numsteps: {}, episode steps: {}, reward: {}".format(i_episode, total_numsteps, episode_steps[i], round(episode_reward[i], 2)))
            i_episode = i_episode + 1
            episode_reward[i] = 0
            episode_steps[i] = 0

            if i_episode % 1000 == 0:
                agent.save_checkpoint('', checkpoint_name)
                memory.save_buffer('', checkpoint_name)

    #state = next_state
    state = default_next_state

    if total_numsteps > args.num_steps:
        break

envs.close()

