from gym.envs.registration import register

register(
    id='DSReach-v0',
    entry_point='DSenv.a0509Reach:a0509ReachEnv',
    max_episode_steps=50,
)

register(
    id='DSpos-v0',
    entry_point='DSenv.a0509.a0509pos:a0509posEnv',
    max_episode_steps=50,
)

register(
    id='RG6-v0',
    entry_point='DSenv.gripper.RG6:RG6Env',
    max_episode_steps=50,
)

register(
    id='RG6S-v0',
    entry_point='DSenv.gripper.RG6S:RG6SEnv',
    max_episode_steps=50,
)

register(
    id='RG6SG-v0',
    entry_point='DSenv.gripper.RG6SG:RG6SGEnv',
    max_episode_steps=50,
)

register(
    id='RG6PP-v0',
    entry_point='DSenv.gripper.RG6PP:RG6PPEnv',
    max_episode_steps=50,
)

register(
    id='RG6j-v0',
    entry_point='DSenv.gripper.RG6j:RG6jEnv',
    max_episode_steps=50,
)

register(
    id='RG6j2-v0',
    entry_point='DSenv.gripper.RG6j2:RG6j2Env',
    max_episode_steps=50,
)

register(
    id='RG6j3-v0',
    entry_point='DSenv.gripper.RG6j3:RG6j3Env',
    max_episode_steps=50,
)

register(
    id='RG6pos-v0',
    entry_point='DSenv.gripper.RG6pos:RG6posEnv',
    max_episode_steps=50,
)

register(
    id='RG6pxz-v0',
    entry_point='DSenv.gripper.RG6pxz:RG6pxzEnv',
    max_episode_steps=50,
)
register(
    id='RG6Sxz-v0',
    entry_point='DSenv.gripper.RG6Sxz:RG6SxzEnv',
    max_episode_steps=50,
)

register(
    id='RG6pz-v0',
    entry_point='DSenv.gripper.RG6pz:RG6pzEnv',
    max_episode_steps=50,
)