import numpy as np

from gym.envs.robotics import rotations, robot_env, utils


def goal_distance(goal_a, goal_b):
    assert goal_a.shape == goal_b.shape
    return np.linalg.norm(goal_a - goal_b, axis=-1)

def normalize(item, low, high):
    if low == high:
        return 0
    else: 
        middle = (high + low) / 2
        mid_len = (high - middle) / 2
        return (item - middle) / mid_len

def unnormalize(item, low, high):
    middle = (high + low) / 2
    mid_len = (high - middle) / 2
    return item * mid_len + middle

def jog_normalize(jog, lows, highs):
    normalized_jog = [0,0,0,0]

    for i in range(len(normalized_jog)):
        normalized_jog[i] = normalize(jog[i], lows[i], highs[i])
    
    return normalized_jog

def jog_unnormalize(jog, lows, highs):
    unnormalized_jog = [0,0,0,0]

    for i in range(len(unnormalized_jog)):
        unnormalized_jog[i] = unnormalize(jog[i], lows[i], highs[i])
    
    return unnormalized_jog

def coord_normalize(coords, lows, highs):
    normalized_coords = [0,0,0]

    for i in range(len(coords)):
        normalized_coords[i] = normalize(coords[i], lows[i], highs[i])
    
    return normalized_coords




class DSEnv(robot_env.RobotEnv):
    """Superclass for all Fetch environments.
    """

    def __init__(
        self, model_path, n_substeps, gripper_extra_height, block_gripper,
        has_object, target_in_the_air, target_offset, obj_range, target_range,
        distance_threshold, initial_qpos, reward_type,
    ):
        """Initializes a new Fetch environment.

        Args:
            model_path (string): path to the environments XML file
            n_substeps (int): number of substeps the simulation runs on every call to step
            gripper_extra_height (float): additional height above the table when positioning the gripper
            block_gripper (boolean): whether or not the gripper is blocked (i.e. not movable) or not
            has_object (boolean): whether or not the environment has an object
            target_in_the_air (boolean): whether or not the target should be in the air above the table or on the table surface
            target_offset (float or array with 3 elements): offset of the target
            obj_range (float): range of a uniform distribution for sampling initial object positions
            target_range (float): range of a uniform distribution for sampling a target
            distance_threshold (float): the threshold after which a goal is considered achieved
            initial_qpos (dict): a dictionary of joint names and values that define the initial configuration
            reward_type ('sparse' or 'dense'): the reward type, i.e. sparse or dense
        """
        self.gripper_extra_height = gripper_extra_height
        self.block_gripper = block_gripper
        self.has_object = has_object
        self.target_in_the_air = target_in_the_air
        self.target_offset = target_offset
        self.obj_range = obj_range
        self.target_range = target_range
        self.distance_threshold = distance_threshold
        self.reward_type = reward_type
        self.distance_threshold_2 = 5

        # self.jog_limit = [[-20, 25, 25, 60], [20, 45, 45, 90]]
        # self.jog_limit = [[-5, 40, 40, 80], [5, 45, 45, 90]]
        self.jog_limit = [[-20, 20, 20, 60], [20, 45, 45, 90]]
        self.full_jog_limit = [[self.jog_limit[0][0], self.jog_limit[0][1], self.jog_limit[0][2], 0, self.jog_limit[0][3], 0], 
                            [self.jog_limit[1][0], self.jog_limit[1][1], self.jog_limit[1][2], 0, self.jog_limit[1][3], 0]]

        self.jog_delta_limit = 10
        self.jog_delta_limit_2 = 1

        super(DSEnv, self).__init__(
            model_path=model_path, n_substeps=n_substeps, n_actions=4,
            initial_qpos=initial_qpos)

    # GoalEnv methods
    # ----------------------------

    def compute_reward(self, achieved_goal, goal, info):
        # Compute distance between goal and the achieved goal.
        #d = goal_distance(achieved_goal, self.normalized_goal)

        unnormalized_ag = np.array(jog_unnormalize(achieved_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 
        unnormalized_g = np.array(jog_unnormalize(self.normalized_goal, lows=self.jog_limit[0], highs=self.jog_limit[1])) 

        d = goal_distance(unnormalized_ag, unnormalized_g)
        if self.reward_type == 'sparse':
            return -(d > self.distance_threshold).astype(np.float32)
        else:
            return -d

    # RobotEnv methods
    # ----------------------------

    def _step_callback(self):
        if self.block_gripper:
            self.sim.forward()

    def _set_action(self, action):
        assert action.shape == (4,)
        action = action.copy()  # ensure that we don't change the action outside of this scope
        #pos_ctrl, gripper_ctrl = action[:3], action[3]

        #pos_ctrl *= 0.05  # limit maximum change in position
        #rot_ctrl = [1., 0., 1., 0.]  # fixed rotation of the end effector, expressed as a quaternion
        #gripper_ctrl = np.array([gripper_ctrl, gripper_ctrl])
        #assert gripper_ctrl.shape == (2,)
        #if self.block_gripper:
        #    gripper_ctrl = np.zeros_like(gripper_ctrl)
        #action = np.concatenate([pos_ctrl, rot_ctrl, gripper_ctrl])

        
        #action = np.array([action[0],action[1],action[2],0,action[3],0])
        # Apply action to simulation.
        jog1 = self.sim.data.get_joint_qpos('joint1')
        jog2 = self.sim.data.get_joint_qpos('joint2')
        jog3 = self.sim.data.get_joint_qpos('joint3')
        jog5 = self.sim.data.get_joint_qpos('joint5')

        cur_jog = np.array([jog1, jog2, jog3, jog5])
        cur_jog = np.rad2deg(cur_jog)
        d_1 = goal_distance(cur_jog ,self.normalized_goal)
        
        if d_1 > self.distance_threshold_2:
            action = jog_unnormalize(action, lows=[-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit,-self.jog_delta_limit], 
                                    highs=[self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit,self.jog_delta_limit])
        else:
            action = jog_unnormalize(action, lows=[-self.jog_delta_limit_2,-self.jog_delta_limit_2,-self.jog_delta_limit_2,-self.jog_delta_limit_2], 
                                    highs=[self.jog_delta_limit_2,self.jog_delta_limit_2,self.jog_delta_limit_2,self.jog_delta_limit_2])
            


        #action = jog_unnormalize(action, lows=self.jog_limit[0], highs=self.jog_limit[1])

        """
        action = [action[0], action[1], action[2], 0, action[3], 0]
        action = np.array(action)

        state = self.sim.get_state()
        cur_jog = state.qpos
        cur_jog = np.rad2deg(cur_jog)
        
        delta_jog = np.subtract(action, cur_jog)
        clipped_jog = np.clip(delta_jog, -self.jog_delta_limit, self.jog_delta_limit)
        clipped_sum_jog = np.add(cur_jog, clipped_jog)

        

        cur_jog += action
        clipped_jog = [0,0,0,0]
        clipped_jog[0] = np.clip(cur_jog[0], self.jog_limit[0][0], self.jog_limit[1][0])
        clipped_jog[1] = np.clip(cur_jog[1], self.jog_limit[0][1], self.jog_limit[1][1])
        clipped_jog[2] = np.clip(cur_jog[2], self.jog_limit[0][2], self.jog_limit[1][2])
        clipped_jog[3] = np.clip(cur_jog[4], self.jog_limit[0][3], self.jog_limit[1][3])
        """

        action = np.array(action)

        # state = self.sim.get_state()
        # cur_jog = state.qpos
        # cur_jog = np.rad2deg(cur_jog)
        # cur_jog = np.array([cur_jog[0], cur_jog[1], cur_jog[2], cur_jog[4]])
      

        cur_jog += action
        cur_jog[0] = np.clip(cur_jog[0], self.jog_limit[0][0], self.jog_limit[1][0])
        cur_jog[1] = np.clip(cur_jog[1], self.jog_limit[0][1], self.jog_limit[1][1])
        cur_jog[2] = np.clip(cur_jog[2], self.jog_limit[0][2], self.jog_limit[1][2])
        cur_jog[3] = np.clip(cur_jog[3], self.jog_limit[0][3], self.jog_limit[1][3])

        #clipped_sum_jog = np.deg2rad(clipped_sum_jog)
        clipped_sum_jog = np.deg2rad(cur_jog)
        
        #print(self.sim.data.get_joint_xpos('joint6'))

        self.sim.data.set_joint_qpos('joint1', clipped_sum_jog[0])
        self.sim.data.set_joint_qpos('joint2', clipped_sum_jog[1])
        self.sim.data.set_joint_qpos('joint3', clipped_sum_jog[2])
        self.sim.data.set_joint_qpos('joint5', clipped_sum_jog[3])

        self.sim.data.set_joint_qpos('finger_joint', 0)
        #self.sim.data.set_joint_qpos('joint5', clipped_sum_jog[4])

        #print(self.sim.data.get_joint_xpos('joint6'))
        #print(action, np.rad2deg(self.sim.get_state().qpos))

        #utils.ctrl_set_action(self.sim, action)
        #utils.mocap_set_action(self.sim, action)

    def _get_obs(self):
        # positions
        #cur_pos = self.sim.data.get_joint_xpos('joint6')
        dt = self.sim.nsubsteps * self.sim.model.opt.timestep

        jog1 = self.sim.data.get_joint_qpos('joint1')
        jog2 = self.sim.data.get_joint_qpos('joint2')
        jog3 = self.sim.data.get_joint_qpos('joint3')
        jog5 = self.sim.data.get_joint_qpos('joint5')

        cur_jog = np.array((jog1, jog2, jog3, jog5))
        cur_jog = np.rad2deg(cur_jog)

        #print(cur_jog, self.goal)

        cur_jog = np.array(jog_normalize(cur_jog, lows=self.jog_limit[0], highs=self.jog_limit[1]))        


        achieved_goal = cur_jog.copy()

        obs = np.concatenate([cur_jog])

        

        return {
            'observation': obs.copy(),
            'achieved_goal': achieved_goal.copy(),
            'desired_goal': self.normalized_goal,
            #'desired_goal': self.goal.copy(),
        }

    def _viewer_setup(self):
        body_id = self.sim.model.body_name2id('link6')
        lookat = self.sim.data.body_xpos[body_id]
        for idx, value in enumerate(lookat):
            self.viewer.cam.lookat[idx] = value
        self.viewer.cam.distance = 2.5
        self.viewer.cam.azimuth = 132.
        self.viewer.cam.elevation = -14.

    def _render_callback(self):
        # Visualize target.

        jog1 = self.sim.data.get_joint_qpos('joint1')
        jog2 = self.sim.data.get_joint_qpos('joint2')
        jog3 = self.sim.data.get_joint_qpos('joint3')
        jog5 = self.sim.data.get_joint_qpos('joint5')


        self.sim.data.set_joint_qpos('joint1', np.deg2rad(self.goal[0]))
        self.sim.data.set_joint_qpos('joint2', np.deg2rad(self.goal[1]))
        self.sim.data.set_joint_qpos('joint3', np.deg2rad(self.goal[2]))
        self.sim.data.set_joint_qpos('joint5', np.deg2rad(self.goal[3]))
        self.sim.step()

        body_id2 = self.sim.model.body_name2id('right_inner_finger')
        lookat2 = self.sim.data.body_xpos[body_id2]

        body_id3 = self.sim.model.body_name2id('left_inner_finger')
        lookat3 = self.sim.data.body_xpos[body_id3]

        lookat0 = (lookat2 + lookat3) / 2

        self.sim.data.set_joint_qpos('joint1', jog1)
        self.sim.data.set_joint_qpos('joint2', jog2)
        self.sim.data.set_joint_qpos('joint3', jog3)
        self.sim.data.set_joint_qpos('joint5', jog5)
        self.sim.step()
            
        sites_offset = (self.sim.data.site_xpos - self.sim.model.site_pos).copy()
        site_id = self.sim.model.site_name2id('target0')
        self.sim.model.site_pos[site_id] = lookat0 - sites_offset[0]
        self.sim.forward()


    def _reset_sim(self):
        self.sim.set_state(self.initial_state)

        # Randomize start position of object.
        if self.has_object:
            object_xpos = self.initial_gripper_xpos[:2]
            while np.linalg.norm(object_xpos - self.initial_gripper_xpos[:2]) < 0.1:
                object_xpos = self.initial_gripper_xpos[:2] + self.np_random.uniform(-self.obj_range, self.obj_range, size=2)
            object_qpos = self.sim.data.get_joint_qpos('object0:joint')
            assert object_qpos.shape == (7,)
            object_qpos[:2] = object_xpos
            self.sim.data.set_joint_qpos('object0:joint', object_qpos)

        self.sim.forward()
        return True

    def _sample_goal(self):
        if self.has_object:
            goal = self.initial_gripper_xpos[:3] + self.np_random.uniform(-self.target_range, self.target_range, size=3)
            goal += self.target_offset
            goal[2] = self.height_offset
            if self.target_in_the_air and self.np_random.uniform() < 0.5:
                goal[2] += self.np_random.uniform(0, 0.45)
        else:
            j1 = np.random.randint(low=self.jog_limit[0][0], high=self.jog_limit[1][0])
            j2 = np.random.randint(low=self.jog_limit[0][1], high=self.jog_limit[1][1])
            j3 = np.random.randint(low=self.jog_limit[0][2], high=self.jog_limit[1][2])
            j5 = np.random.randint(low=self.jog_limit[0][3], high=self.jog_limit[1][3])
            goal = np.array([j1,j2,j3,j5])
            self.normalized_goal = np.array(jog_normalize(goal, lows=self.jog_limit[0], highs=self.jog_limit[1]))

        return goal.copy()

    def _is_success(self, achieved_goal, desired_goal):
        d = goal_distance(achieved_goal, desired_goal)
        return (d < self.distance_threshold).astype(np.float32)

    def _env_setup(self, initial_qpos):
        for name, value in initial_qpos.items():
            self.sim.data.set_joint_qpos(name, value)
        utils.reset_mocap_welds(self.sim)
        self.sim.forward()

        # Move end effector into position.
        #gripper_target = np.array([-0.498, 0.005, -0.431 + self.gripper_extra_height]) + self.sim.data.get_site_xpos('robot0:grip')
        #gripper_rotation = np.array([1., 0., 1., 0.])
        #self.sim.data.set_mocap_pos('robot0:mocap', gripper_target)
        #self.sim.data.set_mocap_quat('robot0:mocap', gripper_rotation)
        for _ in range(10):
            self.sim.step()

        # Extract information for sampling goals.
        #self.initial_gripper_xpos = self.sim.data.get_site_xpos('robot0:grip').copy()
        #if self.has_object:
        #    self.height_offset = self.sim.data.get_site_xpos('object0')[2]

    def render(self, mode='human', width=500, height=500):
        return super(DSEnv, self).render(mode, width, height)
